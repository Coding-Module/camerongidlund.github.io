package matheng;

public class ExpressionTree {
    // algebraic tree class allowing representation of mathematical functions
    // supports symbolic manipulation, evaluation, and differentiation
    
    interface Node {
        // base structure for all nodes in the function tree
        // each node type implements its own behavior
        
        public Node copy();                 // deep copy of subtree
        public Node simplify();             // reduce subtree if possible
        public Node evaluate(String var, double val); // substitute variable with value
        public Node derivative(String var); // symbolic derivative wrt variable
    }
    
    public enum unops {  
        // unary operations (one input)
        sin, cos, tan, sec, csc, cot,
        asin, acos, atan, asec, acsc, acot,
        sinh, cosh, tanh, sech, csch, coth,
        asinh, acosh, atanh, asech, acsch, acoth,
        abs, neg, ln, log
    }
    
    public enum biops {  
        // binary operations (two inputs)
        add, sub, mul, div, pow, logbase
    }
    
    private class constNode implements Node {  
        // constant node: numeric literal (ex. 5, 6.7, pi, e)
        
        private double value;  // stored constant
        
        public constNode(double val) {
            this.value = val;
        }
        
        public Node copy() {
            // constant is atomic, copy is trivial
            return new constNode(this.value);
        }
        
        public double getVal() {
            return this.value;
        }
        
        public Node simplify() {
            // constants are already simplest form
            return this.copy();
        }
        
        public Node evaluate(String var, double val) {
            // constants unaffected by substitution
            return this.copy();
        }
        
        public Node derivative(String var) {
            // derivative of constant is zero
            return new constNode(0);
        }
        
        public String toString() {
            return Double.toString(this.value);
        }
    }
    
    private class varNode implements Node {  
        // variable node: symbolic placeholder (ex. x, y, z)
        
        private String var;  // variable name
        
        public varNode(String var) {
            this.var = var;
        }
        
        public Node copy() {
            // variable is atomic, copy is trivial
            return new varNode(this.var);
        }
        
        public String getVar() {
            return this.var;
        }
        
        public Node simplify() {
            // variables cannot be simplified
            return this.copy();
        }
        
        public Node evaluate(String var, double val) {
            // substitute variable if names match
            if (this.getVar().equals(var))
                return new constNode(val);
            return this.copy();
        }
        
        public Node derivative(String var) {
            // Dx[x] = 1, Dx[y] = 0
            if (this.var.equals(var))
                return new constNode(1);
            return new constNode(0);
        }
        
        public String toString() {
            return this.var;
        }
    }
    
    private class unaryNode implements Node {  // ex. sin(node), ln(node), |node|
        private unops type;      // unary operation being applied
        private Node pointer;    // input expression
        
        public unaryNode(unops type) {
            this.type = type;    // operation only, no child yet
            this.pointer = null;
        }
        public unaryNode(unops type, Node pointer) {
            this.type = type;    // operation
            this.pointer = pointer; // child expression
        }
        
        public Node copy() {
            // deep copy: duplicate operation + recursively copy child
            unaryNode ret = new unaryNode(this.type);
            ret.pointTo(this.pointer.copy());
            return ret;
        }
        
        public void pointTo(Node pointer) {
            // set child expression
            this.pointer = pointer;
        }
        public Node getPointer() {
            return this.pointer;
        }
        public unops type() {
            return this.type;
        }
        
        public Node simplify() {
            // simplify child first
            unaryNode ret = (unaryNode) this.copy();
            Node sPoint = ret.getPointer().simplify();
            ret.pointTo(sPoint);
            
            // if child is constant, evaluate unary op numerically
            if (sPoint instanceof constNode) {
                double x = ((constNode)sPoint).getVal();
                switch (this.type) {
                case abs:   return new constNode(Math.abs(x));
                case acos:  return new constNode(Math.acos(x));
                case acosh: return new constNode(Math.log(x + Math.sqrt(x*x - 1)));
                case acot:  return new constNode(Math.atan(1 / x));
                case acoth: return new constNode(0.5 * Math.log((x + 1) / (x - 1)));
                case acsc:  return new constNode(Math.asin(1 / x));
                case acsch: return new constNode(Math.log((1/x) + Math.sqrt((1/(x*x)) + 1)));
                case asec:  return new constNode(Math.acos(1 / x));
                case asech: return new constNode(Math.log((1 + Math.sqrt(1 - x*x)) / x));
                case asin:  return new constNode(Math.asin(x));
                case asinh: return new constNode(Math.log(x + Math.sqrt(x*x + 1)));
                case atan:  return new constNode(Math.atan(x));
                case atanh: return new constNode(0.5 * Math.log((1 + x) / (1 - x)));
                case cos:   return new constNode(Math.cos(x));
                case cosh:  return new constNode(Math.cosh(x));
                case cot:   return new constNode(1 / Math.tan(x));
                case coth:  return new constNode(1 / Math.tanh(x));
                case csc:   return new constNode(1 / Math.sin(x));
                case csch:  return new constNode(1 / Math.sinh(x));
                case neg:   return new constNode(-x);
                case sec:   return new constNode(1 / Math.cos(x));
                case sech:  return new constNode(1 / Math.cosh(x));
                case sin:   return new constNode(Math.sin(x));
                case sinh:  return new constNode(Math.sinh(x));
                case tan:   return new constNode(Math.tan(x));
                case tanh:  return new constNode(Math.tanh(x));
                case ln:    return new constNode(Math.log(x));
                case log:   return new constNode(Math.log10(x));
                }
            }
            
            // simplify neg(neg(x)) → x
            if (this.type == unops.neg &&
                sPoint instanceof unaryNode &&
                ((unaryNode)sPoint).type() == unops.neg) {
                return ((unaryNode)sPoint).getPointer();
            }
            
            // simplify abs(abs(x)) → abs(x)
            if (this.type == unops.abs &&
                sPoint instanceof unaryNode &&
                ((unaryNode)sPoint).type() == unops.abs) {
                return sPoint;
            }
            
            // otherwise return simplified unary node
            return ret;
        }
        
        public Node evaluate(String var, double val) {
            // evaluate child then rebuild unary op
            unaryNode ret = (unaryNode) this.copy();
            ret.pointTo(this.pointer.evaluate(var, val));
            return ret;
        }

        public Node derivative(String var) {
            // derivative of unary operation using chain rule
            // ret = (d/dx op(f)) = op'(f) * f'
            
            binaryNode ret = new binaryNode(biops.mul); // final product node
            Node f = this.pointer;                      // inner function
            Node df = this.pointer.derivative(var);     // derivative of inner
            
            switch (this.type) {  // compute derivative of selected unary op
                
            case abs:  
                // d|f| = (f/|f|) * f'
                ret.pointLeft(new binaryNode(
                        biops.div,
                        f.copy(),
                        new unaryNode(unops.abs, f.copy())
                ));
                ret.pointRight(df);
                return ret.simplify();
                
            case acos:
                // d acos(f) = -1 / sqrt(1 - f^2) * f'
                ret.pointLeft(new binaryNode(
                        biops.div,
                        new constNode(-1),
                        new binaryNode(
                                biops.pow,
                                new binaryNode(
                                        biops.sub,
                                        new constNode(1),
                                        new binaryNode(biops.pow, f.copy(), new constNode(2))
                                ),
                                new constNode(0.5)
                        )
                ));
                ret.pointRight(df);
                return ret.simplify();
                
            case acosh:
                // d acosh(f) = 1 / sqrt(f^2 - 1) * f'
                ret.pointLeft(new binaryNode(
                        biops.div,
                        new constNode(1),
                        new binaryNode(
                                biops.pow,
                                new binaryNode(
                                        biops.sub,
                                        new binaryNode(biops.pow, f.copy(), new constNode(2)),
                                        new constNode(1)
                                ),
                                new constNode(0.5)
                        )
                ));
                ret.pointRight(df);
                return ret.simplify();
                
            case acot:
                // d acot(f) = -1 / (1 + f^2) * f'
                ret.pointLeft(new binaryNode(
                        biops.div,
                        new constNode(-1),
                        new binaryNode(
                                biops.add,
                                new binaryNode(biops.pow, f.copy(), new constNode(2)),
                                new constNode(1)
                        )
                ));
                ret.pointRight(df);
                return ret.simplify();
                
            case acoth:
                // d acoth(f) = 1 / (1 - f^2) * f'
                ret.pointLeft(new binaryNode(
                        biops.div,
                        new constNode(1),
                        new binaryNode(
                                biops.sub,
                                new constNode(1),
                                new binaryNode(biops.pow, f.copy(), new constNode(2))
                        )
                ));
                ret.pointRight(df);
                return ret.simplify();
                
            case acsc:
                // d acsc(f) = -1 / (|f| * sqrt(f^2 - 1)) * f'
                ret.pointLeft(new binaryNode(
                        biops.div,
                        new constNode(-1),
                        new binaryNode(
                                biops.mul,
                                new unaryNode(unops.abs, f.copy()),
                                new binaryNode(
                                        biops.pow,
                                        new binaryNode(
                                                biops.sub,
                                                new binaryNode(biops.pow, f.copy(), new constNode(2)),
                                                new constNode(1)
                                        ),
                                        new constNode(0.5)
                                )
                        )
                ));
                ret.pointRight(df);
                return ret.simplify();
                
            case acsch:
                // d acsch(f) = -1 / (|f| * sqrt(1 + f^2)) * f'
                ret.pointLeft(new binaryNode(
                        biops.div,
                        new constNode(-1),
                        new binaryNode(
                                biops.mul,
                                new unaryNode(unops.abs, f.copy()),
                                new binaryNode(
                                        biops.pow,
                                        new binaryNode(
                                                biops.add,
                                                new constNode(1),
                                                new binaryNode(biops.pow, f.copy(), new constNode(2))
                                        ),
                                        new constNode(0.5)
                                )
                        )
                ));
                ret.pointRight(df);
                return ret.simplify();
                
            case asec:
                // d asec(f) = 1 / (|f| * sqrt(f^2 - 1)) * f'
                ret.pointLeft(new binaryNode(
                        biops.div,
                        new constNode(1),
                        new binaryNode(
                                biops.mul,
                                new unaryNode(unops.abs, f.copy()),
                                new binaryNode(
                                        biops.pow,
                                        new binaryNode(
                                                biops.sub,
                                                new binaryNode(biops.pow, f.copy(), new constNode(2)),
                                                new constNode(1)
                                        ),
                                        new constNode(0.5)
                                )
                        )
                ));
                ret.pointRight(df);
                return ret.simplify();
                
            case asech:
                // d asech(f) = -1 / (f * sqrt(1 - f^2)) * f'
                ret.pointLeft(new binaryNode(
                        biops.div,
                        new constNode(-1),
                        new binaryNode(
                                biops.mul,
                                f.copy(),
                                new binaryNode(
                                        biops.pow,
                                        new binaryNode(
                                                biops.sub,
                                                new constNode(1),
                                                new binaryNode(biops.pow, f.copy(), new constNode(2))
                                        ),
                                        new constNode(0.5)
                                )
                        )
                ));
                ret.pointRight(df);
                return ret.simplify();
                
            case asin:
                // d asin(f) = 1 / sqrt(1 - f^2) * f'
                ret.pointLeft(new binaryNode(
                        biops.div,
                        new constNode(1),
                        new binaryNode(
                                biops.pow,
                                new binaryNode(
                                        biops.sub,
                                        new constNode(1),
                                        new binaryNode(biops.pow, f.copy(), new constNode(2))
                                ),
                                new constNode(0.5)
                        )
                ));
                ret.pointRight(df);
                return ret.simplify();
                
            case asinh:
                // d asinh(f) = 1 / sqrt(1 + f^2) * f'
                ret.pointLeft(new binaryNode(
                        biops.div,
                        new constNode(1),
                        new binaryNode(
                                biops.pow,
                                new binaryNode(
                                        biops.add,
                                        new constNode(1),
                                        new binaryNode(biops.pow, f.copy(), new constNode(2))
                                ),
                                new constNode(0.5)
                        )
                ));
                ret.pointRight(df);
                return ret.simplify();
                
            case atan:
                // d atan(f) = 1 / (1 + f^2) * f'
                ret.pointLeft(new binaryNode(
                        biops.div,
                        new constNode(1),
                        new binaryNode(
                                biops.add,
                                new binaryNode(biops.pow, f.copy(), new constNode(2)),
                                new constNode(1)
                        )
                ));
                ret.pointRight(df);
                return ret.simplify();
                
            case atanh:
                // d atanh(f) = 1 / (1 - f^2) * f'
                ret.pointLeft(new binaryNode(
                        biops.div,
                        new constNode(1),
                        new binaryNode(
                                biops.sub,
                                new constNode(1),
                                new binaryNode(biops.pow, f.copy(), new constNode(2))
                        )
                ));
                ret.pointRight(df);
                return ret.simplify();
                
            case cos:
                // d cos(f) = -sin(f) * f'
                ret.pointLeft(new unaryNode(unops.sin, f.copy()));
                ret.pointRight(df);
                return new unaryNode(unops.neg, ret).simplify();
                
            case cosh:
                // d cosh(f) = sinh(f) * f'
                ret.pointLeft(new unaryNode(unops.sinh, f.copy()));
                ret.pointRight(df);
                return ret.simplify();
                
            case cot:
                // d cot(f) = -csc^2(f) * f'
                ret.pointLeft(new binaryNode(
                        biops.pow,
                        new unaryNode(unops.csc, f.copy()),
                        new constNode(2)
                ));
                ret.pointRight(df);
                return new unaryNode(unops.neg, ret).simplify();
                
            case coth:
                // d coth(f) = -csch^2(f) * f'
                ret.pointLeft(new binaryNode(
                        biops.pow,
                        new unaryNode(unops.csch, f.copy()),
                        new constNode(2)
                ));
                ret.pointRight(df);
                return new unaryNode(unops.neg, ret).simplify();
                
            case csc:
                // d csc(f) = -csc(f)cot(f) * f'
                ret.pointLeft(new binaryNode(
                        biops.mul,
                        new unaryNode(unops.csc, f.copy()),
                        new unaryNode(unops.cot, f.copy())
                ));
                ret.pointRight(df);
                return new unaryNode(unops.neg, ret).simplify();
                
            case csch:
                // d csch(f) = -csch(f)coth(f) * f'
                ret.pointLeft(new binaryNode(
                        biops.mul,
                        new unaryNode(unops.csch, f.copy()),
                        new unaryNode(unops.coth, f.copy())
                ));
                ret.pointRight(df);
                return new unaryNode(unops.neg, ret).simplify();
                
            case ln:
                // d ln(f) = 1/f * f'
                ret.pointLeft(new binaryNode(
                        biops.div,
                        new constNode(1),
                        f.copy()
                ));
                ret.pointRight(df);
                return ret.simplify();
                
            case log:
                // d log10(f) = 1 / (f ln(10)) * f'
                ret.pointLeft(new binaryNode(
                        biops.div,
                        new constNode(1),
                        new binaryNode(biops.mul, f.copy(), new constNode(Math.log(10)))
                ));
                ret.pointRight(df);
                return ret.simplify();
                
            case neg:
                // d(-f) = -(f')
                return new unaryNode(unops.neg, df).simplify();
                
            case sec:
                // d sec(f) = sec(f)tan(f) * f'
                ret.pointLeft(new binaryNode(
                        biops.mul,
                        new unaryNode(unops.sec, f.copy()),
                        new unaryNode(unops.tan, f.copy())
                ));
                ret.pointRight(df);
                return ret.simplify();
                
            case sech:
                // d sech(f) = -sech(f)tanh(f) * f'
                ret.pointLeft(new binaryNode(
                        biops.mul,
                        new unaryNode(unops.sech, f.copy()),
                        new unaryNode(unops.tanh, f.copy())
                ));
                ret.pointRight(df);
                return new unaryNode(unops.neg, ret).simplify();
                
            case sin:
                // d sin(f) = cos(f) * f'
                ret.pointLeft(new unaryNode(unops.cos, f.copy()));
                ret.pointRight(df);
                return ret.simplify();
                
            case sinh:
                // d sinh(f) = cosh(f) * f'
                ret.pointLeft(new unaryNode(unops.cosh, f.copy()));
                ret.pointRight(df);
                return ret.simplify();
                
            case tan:
                // d tan(f) = sec^2(f) * f'
                ret.pointLeft(new binaryNode(
                        biops.pow,
                        new unaryNode(unops.sec, f.copy()),
                        new constNode(2)
                ));
                ret.pointRight(df);
                return ret.simplify();
                
            case tanh:
                // d tanh(f) = sech^2(f) * f'
                ret.pointLeft(new binaryNode(
                        biops.pow,
                        new unaryNode(unops.sech, f.copy()),
                        new constNode(2)
                ));
                ret.pointRight(df);
                return ret.simplify();
                
            default:
                return null;
            }
        }

        public String toString() {
            // string representation of unary operation applied to child
            // prints in standard mathematical notation
            
            switch (this.type) {
            case sin:   return "sin("  + this.pointer.toString() + ")";
            case cos:   return "cos("  + this.pointer.toString() + ")";
            case tan:   return "tan("  + this.pointer.toString() + ")";
            case sec:   return "sec("  + this.pointer.toString() + ")";
            case csc:   return "csc("  + this.pointer.toString() + ")";
            case cot:   return "cot("  + this.pointer.toString() + ")";
            
            case asin:  return "asin(" + this.pointer.toString() + ")";
            case acos:  return "acos(" + this.pointer.toString() + ")";
            case atan:  return "atan(" + this.pointer.toString() + ")";
            case asec:  return "asec(" + this.pointer.toString() + ")";
            case acsc:  return "acsc(" + this.pointer.toString() + ")";
            case acot:  return "acot(" + this.pointer.toString() + ")";
            
            case sinh:  return "sinh(" + this.pointer.toString() + ")";
            case cosh:  return "cosh(" + this.pointer.toString() + ")";
            case tanh:  return "tanh(" + this.pointer.toString() + ")";
            case sech:  return "sech(" + this.pointer.toString() + ")";
            case csch:  return "csch(" + this.pointer.toString() + ")";
            case coth:  return "coth(" + this.pointer.toString() + ")";
            
            case asinh: return "asinh(" + this.pointer.toString() + ")";
            case acosh: return "acosh(" + this.pointer.toString() + ")";
            case atanh: return "atanh(" + this.pointer.toString() + ")";
            case asech: return "asech(" + this.pointer.toString() + ")";
            case acsch: return "acsch(" + this.pointer.toString() + ")";
            case acoth: return "acoth(" + this.pointer.toString() + ")";
            
            case abs:   return "|" + this.pointer.toString() + "|";   // absolute value
            case neg:   return "(-" + this.pointer.toString() + ")";  // unary negation
            
            case ln:    return "ln("  + this.pointer.toString() + ")";
            case log:   return "log(" + this.pointer.toString() + ")";
            
            default:    return "";
            }
        }
    }
    
    private class binaryNode implements Node {  
        // binary operation node: f + g, f * g, f^g, etc
        
        private biops type;  // operation type
        private Node left;   // left operand
        private Node right;  // right operand
        
        public binaryNode(biops type) {
            this.type = type;   // operation only
            this.left = null;
            this.right = null;
        }
        public binaryNode(biops type, Node left, Node right) {
            this.type = type;   // operation
            this.left = left;   // left subtree
            this.right = right; // right subtree
        }
        
        public Node copy() {
            // deep copy both children if present
            binaryNode ret = new binaryNode(this.type);
            
            Node L = (this.left  == null ? null : this.left);
            Node R = (this.right == null ? null : this.right);
            
            ret.pointLeft(L == null ? null : L.copy());
            ret.pointRight(R == null ? null : R.copy());
            
            return ret;
        }
        
        public void pointLeft(Node pointer) {
            // set left operand
            this.left = pointer;
        }
        public void pointRight(Node pointer) {
            // set right operand
            this.right = pointer;
        }
        
        public Node getLeft() {
            return this.left;
        }
        public Node getRight() {
            return this.right;
        }
        
        public biops type() {
            return this.type;   // return operation type
        }

        public Node simplify() {

            // simplify both operands first
            Node sLeft  = (this.left  == null ? null : this.left.simplify());
            Node sRight = (this.right == null ? null : this.right.simplify());
            this.left  = sLeft;
            this.right = sRight;

            // constant folding: evaluate binary op numerically when both sides are constants
            if (sLeft instanceof constNode && sRight instanceof constNode) {
                double x = ((constNode)sLeft).getVal();
                double y = ((constNode)sRight).getVal();
                switch (this.type) {
                case add:     return new constNode(x + y);
                case sub:     return new constNode(x - y);
                case mul:     return new constNode(x * y);
                case div:     return new constNode(x / y);
                case pow:     return new constNode(Math.pow(x, y));
                case logbase: return new constNode(Math.log(x) / Math.log(y));
                }
            }

            // identity simplifications for each binary operator
            switch (this.type) {

            case add:
                // 0 + a = a, a + 0 = a
                if (ExpressionTree.isNodeZero(sLeft))  return sRight;
                if (ExpressionTree.isNodeZero(sRight)) return sLeft;
                break;

            case sub:
                // a - 0 = a
                if (ExpressionTree.isNodeZero(sRight)) return sLeft;
                // a - a = 0
                if (ExpressionTree.compareNodes(sLeft, sRight) == 0) return new constNode(0);
                // 0 - a = -a
                if (ExpressionTree.isNodeZero(sLeft))
                    return new unaryNode(unops.neg, sRight);
                break;

            case mul:
                // a * 0 = 0
                if (ExpressionTree.isNodeZero(sLeft) || ExpressionTree.isNodeZero(sRight)) return new constNode(0);
                // a * 1 = a
                if (ExpressionTree.isNodeOne(sLeft))  return sRight;
                if (ExpressionTree.isNodeOne(sRight)) return sLeft;
                break;

            case div:
                // 0 / a = 0
                if (ExpressionTree.isNodeZero(sLeft)) return new constNode(0);
                // a / 1 = a
                if (ExpressionTree.isNodeOne(sRight)) return sLeft;
                break;

            case pow:
                // a^0 = 1, 1^a = 1
                if (ExpressionTree.isNodeZero(sRight) || ExpressionTree.isNodeOne(sLeft)) return new constNode(1);
                // a^1 = a
                if (ExpressionTree.isNodeOne(sRight)) return sLeft;
                break;

            case logbase:
                // log_a(1) = 0
                if (ExpressionTree.isNodeOne(sLeft)) return new constNode(0);
                // log_a(a) = 1
                if (ExpressionTree.compareNodes(sLeft, sRight) == 0) return new constNode(1);
                break;
            }

            // exponent flattening: (base^a)^b = base^(a*b)
            if (this.type == biops.pow &&
                sLeft instanceof binaryNode &&
                ((binaryNode)sLeft).type() == biops.pow &&
                sRight instanceof constNode &&
                ((binaryNode)sLeft).getRight() instanceof constNode) {

                double a = ((constNode)((binaryNode)sLeft).getRight()).getVal();
                double b = ((constNode)sRight).getVal();
                Node base = ((binaryNode)sLeft).getLeft();
                return new binaryNode(biops.pow, base, new constNode(a * b));
            }

            // distributive expansion: (a ± b)*c or a*(b ± c)
            if (this.type == biops.mul) {

                // left distributive: (a ± b)*c = a*c + b*c
                if (sLeft instanceof binaryNode &&
                    (((binaryNode)sLeft).type() == biops.add ||
                     ((binaryNode)sLeft).type() == biops.sub)) {

                    binaryNode add = (binaryNode)sLeft;
                    Node a = add.getLeft();
                    Node b = add.getRight();

                    Node ac = new binaryNode(biops.mul, a, sRight);
                    Node bc = new binaryNode(biops.mul, b, sRight);

                    binaryNode out = new binaryNode(biops.add);
                    out.pointLeft(ac);
                    out.pointRight(bc);
                    return out;
                }

                // right distributive: a*(b ± c) = a*b + a*c
                if (sRight instanceof binaryNode &&
                    (((binaryNode)sRight).type() == biops.add ||
                     ((binaryNode)sRight).type() == biops.sub)) {

                    binaryNode add = (binaryNode)sRight;
                    Node b = add.getLeft();
                    Node c = add.getRight();

                    Node ab = new binaryNode(biops.mul, sLeft, b);
                    Node ac = new binaryNode(biops.mul, sLeft, c);

                    binaryNode out = new binaryNode(biops.add);
                    out.pointLeft(ab);
                    out.pointRight(ac);
                    return out;
                }
            }

            // expand (a ± b)^2 = a^2 + 2ab + b^2
            if (this.type == biops.pow &&
                sRight instanceof constNode &&
                ((constNode)sRight).getVal() == 2 &&
                sLeft instanceof binaryNode &&
                (((binaryNode)sLeft).type() == biops.add ||
                 ((binaryNode)sLeft).type() == biops.sub)) {

                binaryNode base = (binaryNode)sLeft;
                Node a = base.getLeft();
                Node b = base.getRight();

                Node a2 = new binaryNode(biops.pow, a, new constNode(2));
                Node b2 = new binaryNode(biops.pow, b, new constNode(2));
                Node ab = new binaryNode(biops.mul, a, b);
                Node twoab = new binaryNode(biops.mul, new constNode(2), ab);

                binaryNode sum1 = new binaryNode(biops.add);
                sum1.pointLeft(a2);
                sum1.pointRight(twoab);

                binaryNode sum2 = new binaryNode(biops.add);
                sum2.pointLeft(sum1);
                sum2.pointRight(b2);

                return sum2;
            }

            // additive flatten + combine + canonical rebuild
            if (this.type == biops.add || this.type == biops.sub) {

                // flatten nested additions/subtractions into a term list
                java.util.ArrayList<Node> terms = new java.util.ArrayList<>();
                java.util.Stack<Node> stack = new java.util.Stack<>();
                stack.push(this);

                while (!stack.isEmpty()) {
                    Node n = stack.pop();
                    if (n instanceof binaryNode) {
                        binaryNode bn = (binaryNode)n;

                        if (bn.type() == biops.add) {
                            stack.push(bn.getRight());
                            stack.push(bn.getLeft());
                            continue;
                        }
                        if (bn.type() == biops.sub) {
                            stack.push(new unaryNode(unops.neg, bn.getRight()));
                            stack.push(bn.getLeft());
                            continue;
                        }
                    }
                    terms.add(n);
                }

                // collect coefficients for each base term
                java.util.Map<String, Double> coeffs = new java.util.TreeMap<>();
                java.util.Map<String, Node> bases = new java.util.HashMap<>();

                for (Node t : terms) {
                    double c = 1.0;
                    Node b = null;

                    // constant term
                    if (t instanceof constNode) {
                        c = ((constNode)t).getVal();
                    }
                    // unary negation
                    else if (t instanceof unaryNode && ((unaryNode)t).type() == unops.neg) {
                        Node inner = ((unaryNode)t).getPointer();
                        if (inner instanceof constNode) {
                            c = -((constNode)inner).getVal();
                        } else {
                            c = -1.0;
                            b = inner;
                        }
                    }
                    // multiplicative term c*base
                    else if (t instanceof binaryNode && ((binaryNode)t).type() == biops.mul) {
                        binaryNode m = (binaryNode)t;
                        Node L = m.getLeft();
                        Node R = m.getRight();
                        if (L instanceof constNode) {
                            c = ((constNode)L).getVal();
                            b = R;
                        } else if (R instanceof constNode) {
                            c = ((constNode)R).getVal();
                            b = L;
                        } else {
                            b = t;
                        }
                    }
                    // pure base term
                    else {
                        b = t;
                    }

                    String key = (b == null ? "CONST" : b.toString());
                    double old = coeffs.containsKey(key) ? coeffs.get(key) : 0.0;
                    coeffs.put(key, old + c);
                    if (b != null && !bases.containsKey(key)) bases.put(key, b);
                }

                // rebuild ordered term list
                java.util.ArrayList<Node> ordered = new java.util.ArrayList<>();

                for (String key : coeffs.keySet()) {
                    double c = coeffs.get(key);
                    if (Math.abs(c) < 1e-12) continue;

                    Node term;
                    if (key.equals("CONST")) {
                        term = new constNode(c);
                    } else {
                        Node base = bases.get(key);
                        if (Math.abs(c - 1.0) < 1e-12) {
                            term = base;
                        } else {
                            binaryNode m = new binaryNode(biops.mul);
                            m.pointLeft(new constNode(c));
                            m.pointRight(base);
                            term = m;
                        }
                    }

                    ordered.add(term);
                }

                // canonical ordering: by exponent, then lexicographically
                ordered.sort((a, b) -> {
                    boolean aConst = a instanceof constNode;
                    boolean bConst = b instanceof constNode;
                    if (aConst && !bConst) return 1;
                    if (!aConst && bConst) return -1;

                    double ea = 1, eb = 1;
                    Node ba = a, bb = b;

                    if (a instanceof binaryNode && ((binaryNode)a).type() == biops.mul)
                        ba = ((binaryNode)a).getRight();
                    if (b instanceof binaryNode && ((binaryNode)b).type() == biops.mul)
                        bb = ((binaryNode)b).getRight();

                    if (ba instanceof binaryNode &&
                        ((binaryNode)ba).type() == biops.pow &&
                        ((binaryNode)ba).getRight() instanceof constNode)
                        ea = ((constNode)((binaryNode)ba).getRight()).getVal();

                    if (bb instanceof binaryNode &&
                        ((binaryNode)bb).type() == biops.pow &&
                        ((binaryNode)bb).getRight() instanceof constNode)
                        eb = ((constNode)((binaryNode)bb).getRight()).getVal();

                    if (ea != eb) return Double.compare(eb, ea);

                    return ba.toString().compareTo(bb.toString());
                });

                // rebuild additive chain
                Node sum = null;
                for (Node t : ordered) {
                    if (sum == null) sum = t;
                    else {
                        binaryNode add = new binaryNode(biops.add);
                        add.pointLeft(sum);
                        add.pointRight(t);
                        sum = add;
                    }
                }

                if (sum == null) return new constNode(0);
                return sum;
            }

            // multiplicative flatten + combine + canonical rebuild
            if (this.type == biops.mul || this.type == biops.div) {

                // flatten multiplication/division into factor list
                java.util.ArrayList<Node> factors = new java.util.ArrayList<>();
                java.util.Stack<Node> stack = new java.util.Stack<>();
                stack.push(this);

                while (!stack.isEmpty()) {
                    Node n = stack.pop();
                    if (n instanceof binaryNode) {
                        binaryNode bn = (binaryNode)n;

                        if (bn.type() == biops.mul) {
                            stack.push(bn.getRight());
                            stack.push(bn.getLeft());
                            continue;
                        }
                        if (bn.type() == biops.div) {
                            // convert division into multiplication by negative exponent
                            stack.push(new binaryNode(biops.pow, bn.getRight(), new constNode(-1)));
                            stack.push(bn.getLeft());
                            continue;
                        }
                    }
                    factors.add(n);
                }

                // collect exponents for each base
                java.util.Map<String, Double> expMap = new java.util.TreeMap<>();
                java.util.Map<String, Node> baseMap = new java.util.HashMap<>();
                double globalCoeff = 1.0;

                for (Node f : factors) {

                    // numeric coefficient
                    if (f instanceof constNode) {
                        globalCoeff *= ((constNode)f).getVal();
                        continue;
                    }

                    double e = 1.0;
                    Node b = f;

                    // explicit exponent: base^exp
                    if (f instanceof binaryNode && ((binaryNode)f).type() == biops.pow) {
                        binaryNode p = (binaryNode)f;
                        Node L = p.getLeft();
                        Node R = p.getRight();
                        if (R instanceof constNode) e = ((constNode)R).getVal();
                        b = L;

                        // flatten nested exponent: (base^a)^b = base^(a*b)
                        if (L instanceof binaryNode &&
                            ((binaryNode)L).type() == biops.pow &&
                            ((binaryNode)L).getRight() instanceof constNode) {

                            double a = ((constNode)((binaryNode)L).getRight()).getVal();
                            Node realBase = ((binaryNode)L).getLeft();
                            e = e * a;
                            b = realBase;
                        }
                    }

                    String key = b.toString();
                    double oldE = expMap.containsKey(key) ? expMap.get(key) : 0.0;
                    expMap.put(key, oldE + e);
                    baseMap.put(key, b);
                }

                // rebuild ordered factor list
                java.util.ArrayList<Node> ordered = new java.util.ArrayList<>();

                if (Math.abs(globalCoeff - 1.0) > 1e-12)
                    ordered.add(new constNode(globalCoeff));

                for (String key : expMap.keySet()) {
                    double e = expMap.get(key);
                    if (Math.abs(e) < 1e-12) continue;

                    Node base = baseMap.get(key);
                    Node term;

                    if (Math.abs(e - 1.0) < 1e-12) {
                        term = base;
                    } else {
                        term = new binaryNode(biops.pow, base, new constNode(e));
                    }

                    ordered.add(term);
                }

                // canonical ordering: constants first, then descending exponent
                ordered.sort((a, b) -> {
                    boolean aConst = a instanceof constNode;
                    boolean bConst = b instanceof constNode;
                    if (aConst && !bConst) return -1;
                    if (!aConst && bConst) return 1;

                    double ea = 1, eb = 1;

                    if (a instanceof binaryNode &&
                        ((binaryNode)a).type() == biops.pow &&
                        ((binaryNode)a).getRight() instanceof constNode)
                        ea = ((constNode)((binaryNode)a).getRight()).getVal();

                    if (b instanceof binaryNode &&
                        ((binaryNode)b).type() == biops.pow &&
                        ((binaryNode)b).getRight() instanceof constNode)
                        eb = ((constNode)((binaryNode)b).getRight()).getVal();

                    if (ea != eb) return Double.compare(eb, ea);

                    return a.toString().compareTo(b.toString());
                });

                // rebuild multiplicative chain
                Node prod = null;
                for (Node t : ordered) {
                    if (prod == null) prod = t;
                    else {
                        binaryNode m = new binaryNode(biops.mul);
                        m.pointLeft(prod);
                        m.pointRight(t);
                        prod = m;
                    }
                }

                if (prod == null) return new constNode(1);
                return prod;
            }

            // no changes to base node
            return this;
        }
        
        public Node evaluate(String var, double val) {
            // evaluate both operands under substitution var = val
            binaryNode ret = (binaryNode) this.copy();
            ret.pointLeft(this.left.evaluate(var, val));
            ret.pointRight(this.right.evaluate(var, val));
            return ret;
        }

        public Node derivative(String var) {
            // symbolic derivative of binary operations
            // uses standard calculus rules: sum rule, product rule, quotient rule, power rule

            binaryNode ret;
            Node f  = this.left;              // left operand
            Node g  = this.right;             // right operand
            Node df = this.left.derivative(var);  // derivative of left
            Node dg = this.right.derivative(var); // derivative of right

            switch (this.type) {

            case add:
                // d(f + g) = f' + g'
                ret = new binaryNode(this.type);
                ret.pointLeft(df);
                ret.pointRight(dg);
                return ret.simplify();

            case div:
                // d(f/g) = (f'g - fg') / g^2
                ret = new binaryNode(biops.div);
                ret.pointLeft(new binaryNode(
                        biops.sub,
                        new binaryNode(biops.mul, df, g.copy()),
                        new binaryNode(biops.mul, f.copy(), dg)
                ));
                ret.pointRight(new binaryNode(biops.pow, g.copy(), new constNode(2)));
                return ret.simplify();

            case mul:
                // d(f*g) = f'g + fg'
                ret = new binaryNode(biops.add);
                ret.pointLeft(new binaryNode(biops.mul, df, g.copy()));
                ret.pointRight(new binaryNode(biops.mul, f.copy(), dg));
                return ret.simplify();

            case pow:
                // d(f^g) = f^g * ( g' ln(f) + g * (f'/f) )
                ret = new binaryNode(biops.mul);
                ret.pointLeft(new binaryNode(biops.pow, f.copy(), g.copy()));
                ret.pointRight(new binaryNode(
                        biops.add,
                        new binaryNode(
                                biops.mul,
                                dg,
                                new unaryNode(unops.ln, f.copy())
                        ),
                        new binaryNode(
                                biops.mul,
                                g.copy(),
                                new binaryNode(biops.div, df, f.copy())
                        )
                ));
                return ret.simplify();

            case sub:
                // d(f - g) = f' - g'
                ret = new binaryNode(this.type);
                ret.pointLeft(df);
                ret.pointRight(dg);
                return ret.simplify();

            case logbase:
                // d(log_g(f)) = f' / (f ln(g))
                ret = new binaryNode(biops.div);
                ret.pointLeft(df);
                ret.pointRight(new binaryNode(
                        biops.mul,
                        f.copy(),
                        new unaryNode(unops.ln, g.copy())
                ));
                return ret.simplify();

            default:
                return null;
            }
        }

        public String toString() {
            // string representation of binary operations
            // prints in standard mathematical notation with minimal parentheses

            String ret = "";

            switch (this.type) {

            case add:
                return this.left.toString() + " + " + this.right.toString();

            case sub:
                return this.left.toString() + " - " + this.right.toString();

            case mul:
                // multiplication prints without explicit operator unless needed
                ret = "";

                // parenthesize left if it is a non-multiplicative binary op
                if (this.left instanceof constNode && this.right instanceof constNode)
                    return this.left.toString() + " * " + this.right.toString();

                if (this.left instanceof binaryNode &&
                    ((binaryNode)this.left).type() != biops.mul &&
                    ((binaryNode)this.left).type() != biops.logbase)
                    ret += "(" + this.left.toString() + ")";
                else
                    ret += this.left.toString();

                // parenthesize right similarly
                if (this.right instanceof binaryNode &&
                    ((binaryNode)this.right).type() != biops.mul &&
                    ((binaryNode)this.right).type() != biops.logbase)
                    ret += "(" + this.right.toString() + ")";
                else
                    ret += this.right.toString();

                return ret;

            case div:
                // division prints a/b with parentheses around complex operands
                ret = "";

                if (this.left instanceof binaryNode &&
                    ((binaryNode)this.left).type() != biops.logbase)
                    ret += "(" + this.left.toString() + ")";
                else
                    ret += this.left.toString();

                ret += "/";

                if (this.right instanceof binaryNode &&
                    ((binaryNode)this.right).type() != biops.logbase)
                    ret += "(" + this.right.toString() + ")";
                else
                    ret += this.right.toString();

                return ret;

            case pow:
                // exponentiation prints a^b with parentheses around complex operands
                ret = "";

                if (this.left instanceof binaryNode &&
                    ((binaryNode)this.left).type() != biops.logbase)
                    ret += "(" + this.left.toString() + ")";
                else
                    ret += this.left.toString();

                ret += "^";

                if (this.right instanceof binaryNode &&
                    ((binaryNode)this.right).type() != biops.logbase)
                    ret += "(" + this.right.toString() + ")";
                else
                    ret += this.right.toString();

                return ret;

            case logbase:
                // log_g(f) prints as log_[g](f)
                ret = "log_";

                if (this.right instanceof binaryNode || this.right instanceof unaryNode)
                    ret += "[" + this.right.toString() + "]";
                else
                    ret += this.right.toString();

                ret += "(" + this.left.toString() + ")";
                return ret;

            default:
                return "";
            }
        }
    }
	
    private Node root;  // root of the algebraic tree, represents full function expression

    public ExpressionTree() {
        // default function = constant 0
        this.root = new constNode(0);
    }
    public ExpressionTree(String var) {
        // function = variable
        this.root = new varNode(var);
    }
    public ExpressionTree(double val) {
        // function = constant
        this.root = new constNode(val);
    }

    protected void _rootOverride(Node root) {
        // internal override of root node
        this.root = root;
    }
    protected Node _accessRoot() {
        // internal access to root node
        return this.root;
    }

    public ExpressionTree copy() {
        // deep copy of entire function tree
    	ExpressionTree ret = new ExpressionTree();
        ret._rootOverride(this.root.copy());
        return ret;
    }

    /* ---------------------------------------------------------
     * operation builders
     * these mutate the function by wrapping the current root
     * inside a new unary or binary node, then simplifying
     * --------------------------------------------------------- */

    public void operate(unops type) {
        // apply unary op: root = type(root)
        unaryNode temp = new unaryNode(type);
        temp.pointTo(this.root);
        this.root = temp.simplify();
    }

    public void operate(biops type, double val) {
        // apply binary op with constant: root = root (type) val
        binaryNode temp = new binaryNode(type);
        temp.pointLeft(this.root);
        temp.pointRight(new constNode(val));
        this.root = temp.simplify();
    }

    public void operate(biops type, String var) {
        // apply binary op with variable: root = root (type) var
        binaryNode temp = new binaryNode(type);
        temp.pointLeft(this.root);
        temp.pointRight(new varNode(var));
        this.root = temp.simplify();
    }

    public void operate(biops type, ExpressionTree f) {
        // apply binary op with another function: root = root (type) f
        binaryNode temp = new binaryNode(type);
        temp.pointLeft(this.root);
        temp.pointRight(f._accessRoot());
        this.root = temp.simplify();
    }

    /* ---------------------------------------------------------
     * reversed operations
     * these place the new operand on the left instead of right
     * --------------------------------------------------------- */

    public void r_operate(biops type, double val) {
        // root = val (type) root
        binaryNode temp = new binaryNode(type);
        temp.pointRight(this.root);
        temp.pointLeft(new constNode(val));
        this.root = temp.simplify();
    }

    public void r_operate(biops type, String var) {
        // root = var (type) root
        binaryNode temp = new binaryNode(type);
        temp.pointRight(this.root);
        temp.pointLeft(new varNode(var));
        this.root = temp.simplify();
    }

    public void r_operate(biops type, ExpressionTree f) {
        // root = f (type) root
        binaryNode temp = new binaryNode(type);
        temp.pointRight(this.root);
        temp.pointLeft(f._accessRoot());
        this.root = temp.simplify();
    }

    /* ---------------------------------------------------------
     * evaluation + differentiation
     * --------------------------------------------------------- */

    public void simplify() {
        // simplify entire function tree
        this.root = this.root.simplify();
    }

    public void evaluate(String var, double val) {
        // substitute var = val, then simplify
        this.root = this.root.evaluate(var, val).simplify();
    }

    public void derivative(String var) {
        // differentiate wrt variable
        this.root = this.root.derivative(var);
    }

    /* ---------------------------------------------------------
     * printing
     * --------------------------------------------------------- */

    public String toString() {
        // print full function expression
        return this.root.toString();
    }
	
    //
	// STATIC METHODS //
	//
	
	// convert string → enum for unary ops
	public static unops unops(String type) {
	    return unops.valueOf(type);
	}
	
	// convert string → enum for binary ops
	public static biops biops(String type) {
	    return biops.valueOf(type);
	}
	
	// numeric gcd for doubles (recursive)
	// treats very small values as zero
	public static double gcd(double a, double b) {
	    return Math.abs(a) < 1e-12 ? Math.abs(b) : gcd(b % a, a);
	}
	
	//
	// STATIC HELPERS //
	//
	
	// check if node is constant zero
	private static boolean isNodeZero(Node x) {
	    return (x instanceof constNode && ((constNode)x).getVal() == 0);
	}
	
	// check if node is constant one
	private static boolean isNodeOne(Node x) {
	    return (x instanceof constNode && ((constNode)x).getVal() == 1);
	}
	
	// structural comparison of two nodes
	// used for simplification and canonical ordering
	private static int compareNodes(Node a, Node b) {
	
	    // compare by class first
	    if (!a.getClass().equals(b.getClass()))
	        return a.getClass().getName().compareTo(b.getClass().getName());
	
	    // constNode: compare numeric value
	    if (a instanceof constNode) {
	        double av = ((constNode)a).getVal();
	        double bv = ((constNode)b).getVal();
	        return Double.compare(av, bv);
	    }
	
	    // varNode: compare variable names
	    if (a instanceof varNode) {
	        return ((varNode)a).getVar().compareTo(((varNode)b).getVar());
	    }
	
	    // unaryNode: compare operator, then child
	    if (a instanceof unaryNode) {
	        unaryNode ua = (unaryNode)a;
	        unaryNode ub = (unaryNode)b;
	
	        int opCmp = ua.type().compareTo(ub.type());
	        if (opCmp != 0) return opCmp;
	
	        return compareNodes(ua.getPointer(), ub.getPointer());
	    }
	
	    // binaryNode: compare operator, then left, then right
	    if (a instanceof binaryNode) {
	        binaryNode ba = (binaryNode)a;
	        binaryNode bb = (binaryNode)b;
	
	        int opCmp = ba.type().compareTo(bb.type());
	        if (opCmp != 0) return opCmp;
	
	        int leftCmp = compareNodes(ba.getLeft(), bb.getLeft());
	        if (leftCmp != 0) return leftCmp;
	
	        return compareNodes(ba.getRight(), bb.getRight());
	    }
	
	    // fallback: compare string forms
	    return a.toString().compareTo(b.toString());
	}

}

