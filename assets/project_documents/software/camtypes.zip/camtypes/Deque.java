package camtypes;

@SuppressWarnings("unchecked")
public class Deque<T> implements camObj {
    class Node<t> {
        private t val;              // stored element
        private Node<t> prev;       // link to previous node
        private Node<t> next;       // link to next node
        private boolean copyFlag;   // prevents infinite recursion during deep copy
        
        public Node(t value) {
            this.val = value;       // set element
            this.prev = null;       // no prev yet
            this.next = null;       // no next yet
            this.copyFlag = false;  // not copying
        }
        public Node<t> copy() {
            this.copyFlag = true;   // mark node as visited
            
            t cVal = this.val;      // clone element
            if (this.val instanceof camObj)
                cVal = (t)((camObj)this.val).copy(); // deep copy element if needed
            
            // copy forward chain only; backward links rebuilt later
            Node<t> cNext = this.next;
            if (this.next != null && !this.next.copied())
                cNext = this.next.copy(); // recursively copy forward
            
            Node<t> cPrev = null;   // prev always rebuilt from forward chain
            
            this.copyFlag = false;  // clear flag
            
            Node<t> ret = new Node<t>(cVal); // new node
            ret.setPrev(cPrev);              // prev rebuilt later
            ret.setNext(cNext);              // attach next
            
            if (ret.getNext() != null)
                ret.getNext().setPrev(ret);  // fix backward link
            
            return ret;
        }
        
        public boolean copied() {
            return this.copyFlag;   // true if node already visited during copy
        }
        
        public t getValue() {
            return this.val;        // return element
        }
        public void setValue(t value) {
            this.val = value;       // update element
        }
        
        public Node<t> getPrev() {
            return this.prev;       // return prev link
        }
        public Node<t> getNext() {
            return this.next;       // return next link
        }
        public void setPrev(Node<t> node) {
            this.prev = node;       // set prev link
        }
        public void setNext(Node<t> node) {
            this.next = node;       // set next link
        }
        
        public Node<t> moveFwd(int nodes) {
            // walk forward n nodes, null-safe
            Node<t> ret = this;
            for (int i = 0; i < nodes; i++)
                if (ret == null)
                    return null;
                else
                    ret = ret.getNext();
            return ret;
        }
        public Node<t> moveBwd(int nodes) {
            // walk backward n nodes, null-safe
            Node<t> ret = this;
            for (int i = 0; i < nodes; i++)
                if (ret == null)
                    return null;
                else
                    ret = ret.getPrev();
            return ret;
        }
        
        public int indexOf(t value) {
            // linear search forward from this node
            Node<t> current = this;
            for (int i = 0; current != null; i++) {
                if (current.getValue() == value)
                    return i;
                current = current.getNext();
            }
            return -1;
        }
        
        public String toString() {
            // stringify element
            String s = "";
            if (this.val instanceof Object)
                s += this.val.toString();
            else
                s += this.val;
            return s;
        }
    }
    
    private Node<T> front;           // first node in deque
    private Node<T> back;            // last node in deque
    private int size;                // number of elements
    
    public Deque() {
        this.front = null;           // empty deque
        this.back = null;
        this.size = 0;
    }
    protected T[] _asList() {
        // convert deque to array by walking forward
        T[] ret = (T[]) new Object[this.size];
        for (int i = 0; i < this.size; i++)
            ret[i] = this.front.moveFwd(i).getValue();
        return ret;
    }
    protected void _arrayOverride(Node<T> arr, int size) {
        // replace internal structure with new chain
        this.front = arr;
        this.back = arr.moveFwd(size - 1);
        this.size = size;
    }
    public camObj copy() {
        // deep copy entire deque by copying forward chain
        Deque<T> ret = new Deque<T>();
        ret._arrayOverride(this.front.copy(), this.size);
        return ret;
    }
    
    public int length() {
        return this.size;            // number of elements
    }
    public boolean isEmpty() {
        return this.size == 0;       // empty check
    }
    public boolean contains(T value) {
        // search from front
        return this.front.indexOf(value) != -1;
    }
    
    public void enqueueFront(T value) {
        // insert new node at front
        Node<T> insert = new Node<T>(value);
        if (this.size == 0)
            this.back = insert;      // first element
        else
            this.front.setPrev(insert);
        insert.setNext(this.front);
        this.front = insert;
        this.size++;
    }
    public void enqueueBack(T value) {
        // insert new node at back
        Node<T> insert = new Node<T>(value);
        if (this.size == 0)
            this.front = insert;     // first element
        else
            this.back.setNext(insert);
        insert.setPrev(this.back);
        this.back = insert;
        this.size++;
    }
    
    public T peekFront() {
        return this.front.getValue(); // view front element
    }
    public T peekBack() {
        return this.back.getValue();  // view back element
    }
    
    public void deleteFront() {
        // remove front node
        if (this.size == 0)
            return;
        if (this.size == 1) {
            this.front = null;
            this.back = null;
        } else {
            this.front = this.front.getNext();
            this.front.setPrev(null);
        }
        this.size--;
    }
    public void deleteBack() {
        // remove back node
        if (this.size == 0)
            return;
        if (this.size == 1) {
            this.front = null;
            this.back = null;
        } else {
            this.back = this.back.getPrev();
            this.back.setNext(null);
        }
        this.size--;
    }
    public void clear() {
        // reset deque
        this.front = null;
        this.back = null;
        this.size = 0;
    }
    
    public T dequeueFront() {
        // pop front
        T ret = this.peekFront();
        this.deleteFront();
        return ret;
    }
    public T dequeueBack() {
        // pop back
        T ret = this.peekBack();
        this.deleteBack();
        return ret;
    }
    
    public String toString() {
        // print deque contents
        String s = "{ Deque | ";
        Node<T> current = this.front;
        for (int i = 0; i < this.size; i++) {
            s += current.toString();
            if (i != this.size -1)
                s += ", ";
            current = current.getNext();
        }
        s += " }";
        return s;
    }
}
