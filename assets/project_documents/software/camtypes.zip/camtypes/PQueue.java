package camtypes;

@SuppressWarnings("unchecked")
public class PQueue<T> implements camObj {
    enum heaptype {max, min}          // heap direction
    private ArrayList<C<T>> heap;     // underlying binary heap
    private heaptype type;            // min or max behavior
    
    public PQueue(boolean isMaxHeap) {
        this.heap = new ArrayList<C<T>>(); // empty heap
        if (isMaxHeap)
            this.type = heaptype.max;      // max heap
        else
            this.type = heaptype.min;      // min heap
    }
    public PQueue(heaptype sort) {
        this.heap = new ArrayList<C<T>>(); // empty heap
        this.type = sort;                  // explicit type
    }
    protected void _treeOverride(ArrayList<C<T>> arr) {
        this.heap = arr;                   // replace heap
    }
    public camObj copy() {
        PQueue<T> ret = new PQueue<T>(this.type); // new queue
        ret._treeOverride((ArrayList<C<T>>)this.heap.copy()); // deep copy
        return ret;
    }
    
    public int size() {
        return this.heap.length();         // number of elements
    }
    
    public int leftChildOf(int i) {
        return 2 * i + 1;                  // left child index
    }
    public int rightChildOf(int i) {
        return 2 * i + 2;                  // right child index
    }
    public int parentOf(int i) {
        // compute parent index for binary heap
        if (i == 1)
            return 0;
        return (i - 2) / 2 + (i % 2);
    }
    
    public void swap(int a, int b) {
        // swap two heap positions
        C<T> temp = this.heap.get(a);
        this.heap.set(a, this.heap.get(b));
        this.heap.set(b, temp);
    }
    
    public void fixUpMin(int index) {
        // bubble up for min heap
        while (index != 0 && this.heap.get(this.parentOf(index)).gt(this.heap.get(index))) {
            this.swap(index, this.parentOf(index));
            index = this.parentOf(index);
        }
    }
    public void fixUpMax(int index) {
        // bubble up for max heap
        while (index != 0 && this.heap.get(this.parentOf(index)).lt(this.heap.get(index))) {
            this.swap(index, this.parentOf(index));
            index = this.parentOf(index);
        }
    }
    
    public void fixDownMin(int index) {
        // bubble down for min heap
        while (this.leftChildOf(index) < this.heap.length()) {
            int temp = this.leftChildOf(index);
            if (temp != this.heap.length() - 1 && this.heap.get(temp).gt(this.heap.get(temp + 1)))
                temp += 1;                 // pick smaller child
            if (this.heap.get(index).le(this.heap.get(temp)))
                break;                     // already ordered
            this.swap(index, temp);
            index = temp;
        }
    }
    public void fixDownMax(int index) {
        // bubble down for max heap
        while (this.leftChildOf(index) < this.heap.length()) {
            int temp = this.leftChildOf(index);
            if (temp != this.heap.length() - 1 && this.heap.get(temp).lt(this.heap.get(temp + 1)))
                temp += 1;                 // pick larger child
            if (this.heap.get(index).ge(this.heap.get(temp)))
                break;                     // already ordered
            this.swap(index, temp);
            index = temp;
        }
    }
    
    public void insert(C<T> value) {
        // insert wrapped value into heap
        heap.append((C<T>)value.copy());
        if (this.type == heaptype.min)
            this.fixUpMin(this.heap.length() - 1);
        if (this.type == heaptype.max)
            this.fixUpMax(this.heap.length() - 1);
    }
    public void insert(T value, double priority) {
        // convenience insert with raw value + priority
        C<T> ret = new C<T>(value);
        ret.setPriority(priority);
        this.insert(ret);
    }
    
    public T peek() {
        // view top element
        return this.heap.get(0).getValue();
    }
    
    public void delete() {
        // remove top element
        this.swap(0, this.heap.length() - 1); // move last to root
        this.heap.remove(this.heap.length() - 1); // pop last
        
        if (this.type == heaptype.min)
            this.fixDownMin(0);
        if (this.type == heaptype.max)
            this.fixDownMax(0);
    }
    
    public T pop() {
        // remove and return top element
        T ret = this.peek();
        this.delete();
        return ret;
    }
    
    public String toString() {
        // print heap contents
        String s = "{ Priority Queue | ";
        if (this.type == heaptype.min)
            s += "min";
        if (this.type == heaptype.max)
            s += "max";
        s += " | ";
        
        C<T> current = this.heap.get(0);
        for (int i = 0; i < this.heap.length(); i++) {
            s += current.toString();
            if (i != this.heap.length() -1) {
                s += ", ";
                current = this.heap.get(i + 1);
            }
        }
        s += " }";
        return s;
    }
    
    public static heaptype minHeap() {
        return heaptype.min;       // convenience
    }
    public static heaptype maxHeap() {
        return heaptype.max;       // convenience
    }
}
