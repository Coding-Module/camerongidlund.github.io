package camtypes;

@SuppressWarnings("unchecked")
public class SortList<T> implements camObj {
    private C<T>[] array;        // sorted array of wrapped values
    private int size;            // number of elements
    
    public SortList() {
        this.array = new C[0];   // start empty
        this.size = 0;
    }
    protected C<T>[] _asList() {
        return this.array;       // raw array view
    }
    protected void _arrayOverride(C<T>[] arr) {
        this.array = arr;        // replace array
        this.size = arr.length;  // update size
    }
    public camObj copy() {
        // deep copy list by cloning each wrapped element
        SortList<T> ret = new SortList<T>();
        C<T>[] temp = new C[this.size];
        for (int i = 0; i < this.size; i++) {
            if (this.array instanceof camObj[])
                temp[i] = (C<T>) ((camObj)this.array[i]).copy(); // deep copy
            else
                temp[i] = this.array[i];                         // shallow copy
        }
        ret._arrayOverride(temp);
        return ret;
    }
    
    public int length() {
        return this.size;        // number of elements
    }
    public boolean isEmpty() {
        return this.size == 0;   // empty check
    }
    
    public T get(int index) {
        // support negative indexing
        if (index < 0)
            index = this.size + index;
        return this.array[index].getValue();
    }
    public boolean contains(C<T> value) {
        // binary search for value
        int a = 0;
        int b = this.size - 1;
        while (a <= b) {
            int mid = a + ((b - a) / 2);
            if (this.array[mid].eq(value))
                return true;
            if (this.array[mid].gt(value))
                b = mid - 1;
            else
                a = mid + 1;
        }
        return false;
    }
    public int indexOf(C<T> value) {
        // binary search index
        int a = 0;
        int b = this.size - 1;
        while (a <= b) {
            int mid = a + ((b - a) / 2);
            if (this.array[mid].eq(value))
                return mid;
            if (this.array[mid].gt(value))
                b = mid - 1;
            else
                a = mid + 1;
        }
        return -1;
    }
    
    private void merge(C<T>[] arr, C<T>[] left, C<T>[] right) {
        // merge two sorted halves
        int i = 0, j = 0, k = 0;
        
        while (i < left.length && j < right.length) {
            if (left[i].le(right[j]))
                arr[k++] = left[i++];
            else
                arr[k++] = right[j++];
        }
        while (i < left.length)
            arr[k++] = left[i++];
        while (j < right.length)
            arr[k++] = right[j++];
    }
    private void mergeSort(C<T>[] arr) {
        // recursive mergesort
        if (arr.length > 1) {
            int mid = arr.length / 2;
            C<T>[] left = new C[mid - 1];          // left half
            C<T>[] right = new C[arr.length - mid]; // right half
            
            System.arraycopy(arr, 0, left, 0, mid - 1);
            System.arraycopy(arr, mid + 1, right, 0, arr.length - mid);
            
            this.mergeSort(left);
            this.mergeSort(right);
            
            this.merge(arr, left, right);
        }
    }
    
    public void append(C<T> value) {
        // add element then re-sort
        C<T>[] temp = new C[this.size + 1];
        for (int i = 0; i < this.size; i++)
            temp[i] = this.array[i];
        temp[this.size] = value;
        this.array = temp;
        this.size++;
        this.mergeSort(this.array);
    }
    public void set(int index, C<T> value) {
        // replace element then re-sort
        this.array[index] = value;
        this.mergeSort(this.array);
    }
    
    public void remove(int index) {
        // support negative indexing
        if (index < 0)
            index = this.size + index;
        if (index < 0)
            index = 0;
        if (index > this.size)
            index = this.size - 1;
        
        // remove element at index
        C<T>[] temp = new C[this.size - 1];
        for (int i = 0; i < index; i++)
            temp[i] = this.array[i];
        for (int i = index + 1; i < this.size; i++)
            temp[i - 1] = this.array[i];
        
        this.array = temp;
        this.size--;
    }
    public void delete(C<T> value) {
        // remove first matching element
        int i = this.indexOf(value);
        if (i == -1)
            return;
        this.remove(i);
    }
    public void clear() {
        // reset list
        this.array = new C[0];
        this.size = 0;
    }
    public T pop(int index) {
        // remove and return element
        T ret = this.get(index);
        this.remove(index);
        return ret;
    }
    
    public SortList<T> subList(int from, int to) {
        // slice array into new sorted list
        C<T>[] temp = new C[to - from];
        for (int i = from; i < to; i++)
            temp[i - from] = this.array[i];
        
        SortList<T> ret = new SortList<T>();
        ret._arrayOverride(temp);
        return ret;
    }
    
    public String toString() {
        // print list contents
        String s = "[ ";
        for (int i = 0; i < this.size; i++) {
            if (!(this.array instanceof Object[]))
                s += this.array[i];
            else
                s += this.array[i].toString();
            
            if (i != this.size - 1)
                s += ", ";
        }
        s += " ]";
        return s;
    }
}
