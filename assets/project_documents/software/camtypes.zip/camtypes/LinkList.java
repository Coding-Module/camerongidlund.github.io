package camtypes;

@SuppressWarnings("unchecked")
public class LinkList<T> implements camObj {
    class Node<t> {
        private t val;              // stored element
        private Node<t> pointer;    // next node in chain
        private boolean copyFlag;   // prevents infinite recursion during deep copy
        
        public Node(t value) {
            this.val = value;       // set element
            this.pointer = null;    // no next yet
            this.copyFlag = false;  // not copying
        }
        public Node<t> copy() {
            this.copyFlag = true;   // mark node as visited
            
            t cVal = this.val;      // clone element
            if (this.val instanceof camObj)
                cVal = (t)((camObj)this.val).copy(); // deep copy element
            
            Node<t> cPoint = this.pointer; // clone forward link
            if (this.pointer != null && !this.pointer.copied())
                cPoint = (Node<t>) this.pointer.copy(); // recursive copy
            
            this.copyFlag = false;  // clear flag
            
            Node<t> ret = new Node<t>(cVal); // new node
            ret.pointTo(cPoint);             // attach next
            return ret;
        }
        
        public boolean copied() {
            return this.copyFlag;   // true if node already visited
        }
        
        public t getValue() {
            return this.val;        // return element
        }
        public void setValue(t value) {
            this.val = value;       // update element
        }
        
        public Node<t> pointer() {
            return this.pointer;    // return next node
        }
        public void pointTo(Node<t> next) {
            this.pointer = next;    // set next node
        }
        
        public Node<t> move(int nodes) {
            // walk forward n nodes
            Node<t> ret = this;
            for (int i = 0; i < nodes; i++)
                ret = ret.pointer();
            return ret;
        }
        
        public int indexOf(t value, int limit) {
            // search forward up to limit nodes
            Node<t> current = this;
            for (int i = 0; i < limit; i++) {
                if (current.getValue() == value)
                    return i;
                current = current.pointer();
            }
            return -1;
        }
        
        public String toString() {
            // stringify element
            String s = "";
            if (this.val instanceof Object)
                s += this.val.toString();
            else
                s += this.val;
            return s;
        }
    }
    
    private Node<T> head;        // first node
    private Node<T> tail;        // last node
    private int size;            // number of elements
    
    public LinkList() {
        this.head = null;         // empty list
        this.tail = null;
        size = 0;
    }
    protected T[] _asList() {
        // convert list to array by walking forward
        T[] ret = (T[]) new Object[this.size];
        for (int i = 0; i < this.size; i++)
            ret[i] = this.head.move(i).getValue();
        return ret;
    }
    protected void _arrayOverride(Node<T> arr, int size) {
        // replace internal chain
        this.tail = arr;
        this.head = arr.pointer();
        this.size = size;
    }
    public camObj copy() {
        // deep copy entire list
        LinkList<T> ret = new LinkList<T>();
        Node<T> cTail = (LinkList<T>.Node<T>) this.tail.copy(); // copy tail forward
        cTail.move(this.size - 1).pointTo(cTail);               // rebuild circular link
        ret._arrayOverride(cTail, this.size);
        return ret;
    }
    
    public int length() {
        return this.size;          // number of elements
    }
    public boolean isEmpty() {
        return this.size == 0;     // empty check
    }
    
    public T get(int index) {
        // support negative indexing by wrapping
        while (index < 0)
            index += this.size;
        return this.head.move(index).getValue();
    }
    public boolean contains(T value) {
        // search entire list
        return this.head.indexOf(value, this.size) != -1;
    }
    public int indexOf(T value) {
        return this.head.indexOf(value, this.size);
    }
    
    public void addFirst(T value) {
        // insert at head
        Node<T> insert = new Node<T>(value);
        insert.pointTo(this.head);
        this.tail.pointTo(insert);
        this.head = insert;
        this.size++;
    }
    public void addLast(T value) {
        // insert at tail
        Node<T> insert = new Node<T>(value);
        insert.pointTo(this.head);
        this.tail.pointTo(insert);
        this.tail = insert;
        this.size++;
    }
    
    public void insert(int index, T value) {
        // wrap index into valid range
        while (index < 0 || index > this.size) {
            if (index < 0)
                index += this.size;
            if (index > this.size)
                index -= this.size;
        }
        
        if (index == 0) {
            this.addFirst(value);
            return;
        }
        if (index == this.size) {
            this.addLast(value);
            return;
        }
        
        Node<T> insert = new Node<T>(value);
        Node<T> prev = this.head.move(index - 1);
        Node<T> next = this.head.move(index);
        prev.pointTo(insert);
        insert.pointTo(next);
        this.size++;
    }
    
    public void remove(int index) {
        // wrap index into valid range
        while (index < 0 || index >= this.size) {
            if (index < 0)
                index += this.size;
            if (index >= this.size)
                index -= this.size;
        }
        
        if (index == 0) {
            // remove head
            this.head = this.head.pointer();
            this.tail.pointTo(this.head);
        }
        else if (index == this.size - 1) {
            // remove tail
            Node<T> temp = this.head.move(-2);
            temp.pointTo(this.head);
            this.tail = temp;
        }
        else {
            // remove middle node
            Node<T> prev = this.head.move(index - 1);
            Node<T> next = this.head.move(index + 1);
            prev.pointTo(next);
        }
        this.size--;
    }
    
    public void delete(T value) {
        // remove first matching element
        int i = this.indexOf(value);
        if (i == -1)
            return;
        this.remove(i);
    }
    
    public void clear() {
        // reset list
        this.head = null;
        this.tail = null;
        this.size = 0;
    }
    
    public T pop(int index) {
        // remove and return element
        T ret = this.get(index);
        this.remove(index);
        return ret;
    }
    
    public LinkList<T> subList(int from, int to) {
        // copy entire list then slice by adjusting pointers
        Node<T> temp = (Node<T>)this.head.copy();
        Node<T> head = temp.move(from);
        Node<T> tail = temp.move(to);
        tail.pointTo(head);
        LinkList<T> ret = new LinkList<T>();
        ret._arrayOverride(tail, to - from);
        return ret;
    }
    
    public void reverse() {
        // rebuild list by popping from end and pushing to front
        int len = this.size;
        for (int i = 0; i < len; i++) {
            T val = this.pop(len - 1);
            this.addFirst(val);
        }
    }
    public LinkList<T> reversed() {
        // return reversed copy
        LinkList<T> ret = (LinkList<T>) this.copy();
        ret.reverse();
        return ret;
    }
    
    public String toString() {
        // print list contents
        String s = "{ ";
        Node<T> current = this.head;
        for (int i = 0; i < this.size; i++) {
            s += current.toString();
            if (i != this.size -1)
                s += ", ";
            current = this.head.pointer();
        }
        s += " }";
        return s;
    }
}
