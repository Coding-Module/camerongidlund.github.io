package camtypes;

@SuppressWarnings("unchecked")
public class BST<T> implements camObj {
    class Node<t> {
        private C<t> key;              // node value
        private Node<t> left, right;   // children

        Node(C<t> key) {
            this.key = key;            // set value
            this.left = null;          // init left
            this.right = null;         // init right
        }
        public Node<t> copy() {
            Node<t> ret = new Node<t>((C<t>)this.key.copy()); // deep copy key
            ret.pointLeft(this.left.copy());                  // copy left subtree
            ret.pointRight(this.right.copy());                // copy right subtree
            return ret;                                       // return clone
        }
        
        public C<t> getValue() {
            return this.key;           // return value
        }
        public void setValue(C<t> key) {
            this.key = key;            // set value
        }
        
        public Node<t> getRight() {
            return this.right;         // return right child
        }
        public void pointRight(Node<t> pointer) {
            this.right = pointer;      // set right child
        }
        
        public Node<t> getLeft() {
            return this.left;          // return left child
        }
        public void pointLeft(Node<t> pointer) {
            this.left = pointer;       // set left child
        }
        
        public int size() {
            int s = 1;                 // count self
            int sl = 0;                // left size
            int sr = 0;                // right size
            if (this.left != null)
                sl = this.left.size(); // compute left
            if (this.right != null)
                sr = this.right.size();// compute right
            return s + sl + sr;        // total size
        }
    }
    private Node<T> root;              // tree root
    
    public BST() {
        this.root = null;              // start empty
    }
    protected void _rootOverride(Node<T> root) {
        this.root = root;              // replace root
    }
    public camObj copy() {
        BST<T> ret = new BST<T>();     // new tree
        ret._rootOverride(this.root.copy()); // deep copy root
        return ret;                     // return clone
    }
    
    public int size() {
        return this.root.size();        // tree size
    }

    public void insert(C<T> key) {
        Node<T> temp = this.root;        // start at root
        if (root == null)                // empty tree
            root = new Node<T>(key);
        else {
            while (true)
                if (temp.getValue().gt(key)) { // go left
                    if (temp.getLeft() == null) {
                        temp.pointLeft(new Node<T>(key)); // insert
                        break;
                    } else {
                        temp = temp.getLeft();            // descend
                    }
                }
                else {                      // go right
                    if (temp.getRight() == null) {
                        temp.pointRight(new Node<T>(key)); // insert
                        break;
                    } else {
                        temp = temp.right;                // descend
                    }
                }
        }
    }
    
    public void delete(C<T> key) {
        Node<T> temp = this.searchNode(key); // find node
        Node<T> prev = this.searchPrev(key); // find parent
        if (temp == null)                    // missing
            return;
        
        if (temp.getRight() == null && temp.getLeft() == null) { // leaf
            if (prev.getValue().gt(temp.getValue())) {
                prev.pointLeft(null);      // remove leaf
                return;
            }
            prev.pointRight(null);
            return;
        }
        if (temp.getRight() == null) {      // one child left
            if (prev.getValue().gt(temp.getValue())) {
                prev.pointLeft(temp.getLeft());
                return;
            }
            prev.pointRight(temp.getLeft());
            return;
        }
        if (temp.left == null) {            // one child right
            if (prev.getValue().gt(temp.getValue())) {
                prev.pointLeft(temp.getRight());
                return;
            }
            prev.pointRight(temp.getRight());
            return;
        }
        // two children
        Node<T> min = this.getMin(temp.getRight()); // successor
        this.delete(min.getValue());                // remove successor
        min.pointLeft(temp.getLeft());              // attach children
        min.pointRight(temp.getRight());
        if (prev.getValue().gt(temp.getValue())) {
            prev.pointLeft(min);                    // replace node
            return;
        }
        prev.pointRight(min);
        return;
    }

    public String inorder(Node<T> root) {
        String s = "";                   // traversal string
        if (root == null)
            return s;
        s += inorder(root.getLeft());    // left
        s += root.getValue().toString() + " "; // self
        s += inorder(root.getRight());   // right
        return s;
    }
    
    public String preorder(Node<T> root) {
        String s = "";                   // traversal string
        if (root == null)
            return s;
        s += root.getValue().toString() + " "; // self
        s += this.preorder(root.left);         // left
        s += this.preorder(root.right);        // right
        return s;
    }
    
    public String postorder(Node<T> root) {
        String s = "";                   // traversal string
        if (root == null)
            return s;
        s += this.postorder(root.left);        // left
        s += this.postorder(root.right);       // right
        s += root.getValue().toString() + " "; // self
        return s;
    }
    
    private Node<T> searchNode(C<T> key) {
        Node<T> temp = this.root;        // start at root
        for (;;) {
            if (temp == null)
                return null;             // not found
            if (temp.getValue().eq(key))
                return temp;             // found
            if (temp.getValue().gt(key))
                temp = temp.getLeft();   // go left
            else
                temp = temp.getRight();  // go right
        }
    }
    
    private Node<T> searchPrev(C<T> key) {
        Node<T> temp = this.root;        // start at root
        for (;;) {
            if (temp == null)
                return null;             // no parent
            if ((temp.getLeft() != null && temp.getLeft().getValue().eq(key)) ||
                (temp.getRight() != null && temp.getRight().getValue().eq(key)))
                return temp;             // parent found
            if (temp.getValue().gt(key))
                temp = temp.getLeft();   // go left
            else
                temp = temp.getRight();  // go right
        }
    }
    
    private Node<T> getMin(Node<T> n) {
        if (n.getLeft() == null)
            return n;                    // smallest
        return getMin(n.getLeft());      // descend left
    }
    @SuppressWarnings("unused")
    private Node<T> getMax(Node<T> n) {
        if (n.getRight() == null)
            return n;                    // largest
        return getMax(n.getRight());     // descend right
    }
    
    public String toString() {
        String s = "(BST: ";             // prefix
        s += this.inorder(this.root);    // inorder print
        return s + ")";                  // close
    }
}
