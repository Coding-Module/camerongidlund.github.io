package camtypes;
import java.util.function.Function;

@SuppressWarnings("unchecked")
public class C<T> implements camObj {
    private T val;                         // stored value
    private double priority;               // numeric weight
    private boolean bool;                  // boolean flag
    private int hash;                      // hash code
    @SuppressWarnings("rawtypes")
    private Function<C[], C> addFunc, subFunc, mulFunc, divFunc, modFunc, powFunc; // binary ops
    @SuppressWarnings("rawtypes")
    private Function<C, C> absFunc, negFunc; // unary ops
    
    @SuppressWarnings("rawtypes")
    public static C passFunc(C arg) {return arg;}     // passthrough unary
    @SuppressWarnings("rawtypes")
    public static C passFunc(C[] arg) {return arg[0];} // passthrough binary
    
    public C(T value) {
        this.val = value;                 // set value
        this.priority = 0;                // default priority
        this.bool = false;                // default bool
        this.hash = 0;                    // default hash
        this.addFunc = C::passFunc;       // default ops
        this.subFunc = C::passFunc;
        this.mulFunc = C::passFunc;
        this.divFunc = C::passFunc;
        this.modFunc = C::passFunc;
        this.powFunc = C::passFunc;
        this.absFunc = C::passFunc;
        this.negFunc = C::passFunc;
    }
    public camObj copy() {
        T cVal = this.val;                // clone value
        if (this.val instanceof camObj)
            cVal = (T) ((camObj) this.val).copy(); // deep copy if needed
        
        C<T> ret = new C<T>(cVal);        // new wrapper
        ret.setPriority(this.priority);  // copy metadata
        ret.setBool(this.bool);
        return ret;
    }
    
    public T getValue() {
        return this.val;                  // return value
    }
    public void setValue(T value) {
        this.val = value;                 // set value
    }
    
    public double priority() {
        return this.priority;             // return priority
    }
    public void setPriority(double priority) {
        this.priority = priority;         // set priority
    }
    
    public boolean bool() {
        return this.bool;                 // return bool
    }
    public void setBool(boolean bool) {
        this.bool = bool;                 // set bool
    }
    
    public int hash() {
        return this.hash;                 // return hash
    }
    public void setHash(int hash) {
        this.hash = hash;                 // set hash
    }
    public int hashFunc(int constraint) {
        return this.hash % constraint;    // bounded hash
    }
    
    @SuppressWarnings("rawtypes")
    public void setAddFunc(Function<C[], C> func) {
        this.addFunc = func;              // override add
    }
    @SuppressWarnings("rawtypes")
    public void setSubFunc(Function<C[], C> func) {
        this.subFunc = func;              // override sub
    }
    @SuppressWarnings("rawtypes")
    public void setMulFunc(Function<C[], C> func) {
        this.mulFunc = func;              // override mul
    }
    @SuppressWarnings("rawtypes")
    public void setDivFunc(Function<C[], C> func) {
        this.divFunc = func;              // override div
    }
    @SuppressWarnings("rawtypes")
    public void setModFunc(Function<C[], C> func) {
        this.modFunc = func;              // override mod
    }
    @SuppressWarnings("rawtypes")
    public void setPowFunc(Function<C[], C> func) {
        this.powFunc = func;              // override pow
    }
    @SuppressWarnings("rawtypes")
    public void setAbsFunc(Function<C, C> func) {
        this.absFunc = func;              // override abs
    }
    @SuppressWarnings("rawtypes")
    public void setNegFunc(Function<C, C> func) {
        this.negFunc = func;              // override neg
    }
    
    public boolean eq(C<T> other) {
        return (this.priority == other.priority()); // equal priority
    }
    public boolean ne(C<T> other) {
        return (this.priority != other.priority()); // not equal
    }
    public boolean gt(C<T> other) {
        return (this.priority > other.priority());  // greater
    }
    public boolean lt(C<T> other) {
        return (this.priority < other.priority());  // less
    }
    public boolean ge(C<T> other) {
        return (this.priority >= other.priority()); // greater equal
    }
    public boolean le(C<T> other) {
        return (this.priority <= other.priority()); // less equal
    }
    
    public boolean not() {
        return !this.bool;                // logical not
    }
    public boolean and(C<T> other) {
        return (this.bool && other.bool()); // logical and
    }
    public boolean or(C<T> other) {
        return (this.bool || other.bool()); // logical or
    }
    public boolean xor(C<T> other) {
        return (this.bool ^ other.bool());  // logical xor
    }
    public boolean nand(C<T> other) {
        return !(this.bool && other.bool()); // logical nand
    }
    public boolean nor(C<T> other) {
        return !(this.bool || other.bool()); // logical nor
    }
    public boolean xnor(C<T> other) {
        return !(this.bool ^ other.bool());  // logical xnor
    }
    
    @SuppressWarnings("rawtypes")
    public C add(C other) {
        C[] lst = {this, other};         // binary args
        return this.addFunc.apply(lst);  // apply add
    }
    @SuppressWarnings("rawtypes")
    public C sub(C other) {
        C[] lst = {this, other};
        return this.subFunc.apply(lst);  // apply sub
    }
    @SuppressWarnings("rawtypes")
    public C mul(C other) {
        C[] lst = {this, other};
        return this.mulFunc.apply(lst);  // apply mul
    }
    @SuppressWarnings("rawtypes")
    public C div(C other) {
        C[] lst = {this, other};
        return this.divFunc.apply(lst);  // apply div
    }
    @SuppressWarnings("rawtypes")
    public C mod(C other) {
        C[] lst = {this, other};
        return this.modFunc.apply(lst);  // apply mod
    }
    @SuppressWarnings("rawtypes")
    public C pow(C other) {
        C[] lst = {this, other};
        return this.powFunc.apply(lst);  // apply pow
    }
    
    @SuppressWarnings("rawtypes")
    public C abs() {
        return this.absFunc.apply(this); // apply abs
    }
    @SuppressWarnings("rawtypes")
    public C neg() {
        return this.negFunc.apply(this); // apply neg
    }
    
    
    public String toString() {
        String s = "";                   // stringify
        if (this.val instanceof Object)
            s += this.val.toString();    // object print
        else
            s += this.val;               // raw print
        return s;
    }
    
    @SuppressWarnings("rawtypes")
    public static C<String> cString(String s) {
        C<String> ret = new C<String>(s); // wrap string
        ret.setPriority(s.length());      // priority = length
        ret.setBool(s.length() != 0);     // bool = nonempty
        
        int ascii = 0;                    // ascii sum hash
        for (int i = 0; i < s.length(); i++)
            ascii += (int) s.charAt(i);
        ret.setHash(ascii);
        
        class Arithmetics extends C {     // string ops
            public Arithmetics(Object value) {
                super(value);
            }

            public static C<String> add(C[] lst) { // concat
                String s;
                if (lst[1].getValue() instanceof String)
                    s = (String)lst[0].getValue() + (String)lst[1].getValue();
                else
                    s = null;
                return C.cString(s);
            }
        }
        ret.setAddFunc(Arithmetics::add); // override add
        
        return ret;
    }
    public static C<Integer> cInt(int n) {
        C<Integer> ret = new C<Integer>(n); // wrap int
        ret.setPriority(n);                 // priority = value
        ret.setBool(n != 0);                // bool = nonzero
        ret.setHash(n);                     // hash = value
        return ret;
    }
    public static C<Double> cDouble(double n) {
        C<Double> ret = new C<Double>(n);   // wrap double
        ret.setPriority(n);                 // priority = value
        ret.setBool(n != 0);                // bool = nonzero
        ret.setHash((int) n);               // hash = int cast
        return ret;
    }
    public static C<Boolean> cBool(boolean b) {
        C<Boolean> ret = new C<Boolean>(b); // wrap bool
        if (b) {ret.setPriority(1); ret.setHash(1);} // true meta
        else   {ret.setPriority(0); ret.setHash(0);} // false meta
        ret.setBool(b);
        return ret;
    }
}
