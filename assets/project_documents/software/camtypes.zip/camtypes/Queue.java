package camtypes;

@SuppressWarnings("unchecked")
public class Queue<T> implements camObj {
    class Node<t> {
        private t val;              // stored element
        private Node<t> pointer;    // next node in chain
        private boolean copyFlag;   // prevents infinite recursion during deep copy
        
        public Node(t value) {
            this.val = value;       // set element
            this.pointer = null;    // no next yet
            this.copyFlag = false;  // not copying
        }
        public Node<t> copy() {
            this.copyFlag = true;   // mark node as visited
            
            t cVal = this.val;      // clone element
            if (this.val instanceof camObj)
                cVal = (t)((camObj)this.val).copy(); // deep copy element
            
            Node<t> cPoint = this.pointer; // clone forward link
            if (this.pointer != null && !this.pointer.copied())
                cPoint = this.pointer.copy(); // recursive copy
            
            this.copyFlag = false;  // clear flag
            
            Node<t> ret = new Node<t>(cVal); // new node
            ret.pointTo(cPoint);             // attach next
            return ret;
        }
        
        public boolean copied() {
            return this.copyFlag;   // true if node already visited
        }
        
        public t getValue() {
            return this.val;        // return element
        }
        public void setValue(t value) {
            this.val = value;       // update element
        }
        
        public Node<t> pointer() {
            return this.pointer;    // return next node
        }
        public void pointTo(Node<t> next) {
            this.pointer = next;    // set next node
        }
        
        public Node<t> move(int nodes) {
            // walk forward n nodes
            Node<t> ret = this;
            for (int i = 0; i < nodes; i++)
                ret = ret.pointer();
            return ret;
        }
        
        public int indexOf(t value, int limit) {
            // search forward up to limit nodes
            Node<t> current = this;
            for (int i = 0; i < limit; i++) {
                if (current.getValue() == value)
                    return i;
                current = current.pointer();
            }
            return -1;
        }
        
        public String toString() {
            // stringify element
            String s = "";
            if (this.val instanceof Object)
                s += this.val.toString();
            else
                s += this.val;
            return s;
        }
    }
    
    private Node<T> front;        // first node in queue
    private Node<T> back;         // last node in queue
    private int size;             // number of elements
    
    public Queue() {
        this.front = null;         // empty queue
        this.back = null;
        this.size = 0;
    }
    protected T[] _asList() {
        // convert queue to array by walking forward
        T[] ret = (T[]) new Object[this.size];
        for (int i = 0; i < this.size; i++)
            ret[i] = this.front.move(i).getValue();
        return ret;
    }
    protected void _arrayOverride(Node<T> arr, int size) {
        // replace internal chain
        this.front = arr;
        this.back = arr.move(size - 1);
        this.size = size;
    }
    public camObj copy() {
        // deep copy entire queue
        Queue<T> ret = new Queue<T>();
        ret._arrayOverride(this.front.copy(), this.size);
        return ret;
    }
    
    public int length() {
        return this.size;          // number of elements
    }
    public boolean isEmpty() {
        return this.size == 0;     // empty check
    }
    public boolean contains(T value) {
        // search entire queue
        return this.front.indexOf(value, this.size) != -1;
    }
    
    public void enqueue(T value) {
        // push element to back
        Node<T> insert = new Node<T>(value);
        if (this.size == 0)
            this.front = insert;   // first element
        else
            this.back.pointTo(insert);
        this.back = insert;
        this.size++;
    }
    public T peek() {
        // view front element
        return this.front.getValue();
    }
    public void delete() {
        // remove front element
        if (this.size == 0)
            return;
        if (this.size == 1) {
            this.front = null;
            this.back = null;
        }
        this.front = this.front.pointer();
        this.size--;
    }
    public void clear() {
        // reset queue
        this.front = null;
        this.back = null;
        this.size = 0;
    }
    public T dequeue() {
        // remove and return front element
        T ret = this.peek();
        this.delete();
        return ret;
    }
    
    public String toString() {
        // print queue contents
        String s = "{ Queue | ";
        Node<T> current = this.front;
        for (int i = 0; i < this.size; i++) {
            s += current.toString();
            if (i != this.size -1)
                s += ", ";
            current = this.front.pointer();
        }
        s += " }";
        return s;
    }
}
