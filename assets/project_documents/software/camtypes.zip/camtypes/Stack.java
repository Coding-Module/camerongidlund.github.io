package camtypes;

@SuppressWarnings("unchecked")
public class Stack<T> implements camObj {
    @SuppressWarnings("hiding")
    class Node<T> {
        private T val;              // stored element
        private Node<T> pointer;    // next node in chain
        private boolean copyFlag;   // prevents infinite recursion during deep copy
        
        public Node(T value) {
            this.val = value;       // set element
            this.pointer = null;    // no next yet
            this.copyFlag = false;  // not copying
        }
        public Node<T> copy() {
            this.copyFlag = true;   // mark node as visited
            
            T cVal = this.val;      // clone element
            if (this.val instanceof camObj)
                cVal = (T)((camObj)this.val).copy(); // deep copy element
            
            Node<T> cPoint = this.pointer; // clone forward link
            if (this.pointer != null && !this.pointer.copied())
                cPoint = (Node<T>) this.pointer.copy(); // recursive copy
            
            this.copyFlag = false;  // clear flag
            
            Node<T> ret = new Node<T>(cVal); // new node
            ret.pointTo(cPoint);             // attach next
            return ret;
        }
        
        public boolean copied() {
            return this.copyFlag;   // true if node already visited
        }
        
        public T getValue() {
            return this.val;        // return element
        }
        public void setValue(T value) {
            this.val = value;       // update element
        }
        
        public Node<T> pointer() {
            return this.pointer;    // return next node
        }
        public void pointTo(Node<T> next) {
            this.pointer = next;    // set next node
        }
        
        public Node<T> move(int nodes) {
            // walk forward n nodes
            Node<T> ret = this;
            for (int i = 0; i < nodes; i++)
                ret = ret.pointer();
            return ret;
        }
        
        public int indexOf(T value, int limit) {
            // search forward up to limit nodes
            Node<T> current = this;
            for (int i = 0; i < limit; i++) {
                if (current.getValue() == value)
                    return i;
                current = current.pointer();
            }
            return -1;
        }
        
        public String toString() {
            // stringify element
            String s = "";
            if (this.val instanceof Object)
                s += this.val.toString();
            else
                s += this.val;
            return s;
        }
    }
    
    private Node<T> top;          // top of stack
    private int size;             // number of elements
    
    public Stack() {
        this.top = null;          // empty stack
        this.size = 0;
    }
    protected T[] _asList() {
        // convert stack to array by walking downward
        T[] ret = (T[]) new Object[this.size];
        for (int i = 0; i < this.size; i++)
            ret[i] = this.top.move(i).getValue();
        return ret;
    }
    protected void _arrayOverride(Node<T> arr, int size) {
        // replace internal chain
        this.top = arr;
        this.size = size;
    }
    public camObj copy() {
        // deep copy entire stack
        Stack<T> ret = new Stack<T>();
        ret._arrayOverride(this.top.copy(), this.size);
        return ret;
    }
    
    public int length() {
        return this.size;          // number of elements
    }
    public boolean isEmpty() {
        return this.size == 0;     // empty check
    }
    public boolean contains(T value) {
        // search entire stack
        return this.top.indexOf(value, this.size) != -1;
    }
    
    public void push(T value) {
        // push element onto top
        Node<T> insert = new Node<T>(value);
        insert.pointTo(this.top);
        this.top = insert;
        this.size++;
    }
    public T peek() {
        // view top element
        return this.top.getValue();
    }
    public void delete() {
        // remove top element
        this.top = this.top.pointer();
        this.size--;
    }
    public void clear() {
        // reset stack
        this.top = null;
        this.size = 0;
    }
    public T pop() {
        // remove and return top element
        T ret = this.peek();
        this.delete();
        return ret;
    }
    
    public String toString() {
        // print stack contents
        String s = "{ Stack | ";
        Node<T> current = this.top;
        for (int i = 0; i < this.size; i++) {
            s += current.toString();
            if (i != this.size -1)
                s += ", ";
            current = this.top.pointer();
        }
        s += " }";
        return s;
    }
}
