package camtypes;

@SuppressWarnings("unchecked")
public class AVLTree<T> implements camObj {
    class Node<t> {
        private C<t> key;              // node value
        private Node<t> left, right;   // children

        Node(C<t> key) {
            this.key = key;            // set value
            this.left = null;          // init left
            this.right = null;         // init right
        }
        public Node<t> copy() {
            Node<t> ret = new Node<t>((C<t>)this.key.copy()); // deep copy key
            ret.pointLeft(this.left.copy());                  // copy left subtree
            ret.pointRight(this.right.copy());                // copy right subtree
            return ret;                                       // return clone
        }
        
        public C<t> getValue() {
            return this.key;           // return value
        }
        public void setValue(C<t> key) {
            this.key = key;            // set value
        }
        
        public Node<t> getRight() {
            return this.right;         // return right child
        }
        public void pointRight(Node<t> pointer) {
            this.right = pointer;      // set right child
        }
        
        public Node<t> getLeft() {
            return this.left;          // return left child
        }
        public void pointLeft(Node<t> pointer) {
            this.left = pointer;       // set left child
        }
        
        public int size() {
            int s = 1;                 // count self
            int sl = 0;                // left size
            int sr = 0;                // right size
            if (this.left != null)
                sl = this.left.size(); // compute left
            if (this.right != null)
                sr = this.right.size();// compute right
            return s + sl + sr;        // total size
        }
        
        public int height() {
            int[] ret = new int[2];    // store child heights
            
            if (this.left == null)
                ret[0] = -1;           // empty subtree height
            else
                ret[0] = this.left.height();
            if (this.right == null)
                ret[1] = -1;
            else
                ret[1] = this.right.height();
            
            if (ret[0] > ret[1])        // pick larger
                return ret[0] + 1;
            return ret[1] + 1;
        }
        
        public int BalanceFactor() {
            return this.getLeft().height() - this.getRight().height(); // left minus right
        }
    }
    private Node<T> root;              // tree root
    
    public AVLTree() {
        this.root = null;              // start empty
    }
    protected void _rootOverride(Node<T> root) {
        this.root = root;              // replace root
    }
    public camObj copy() {
        AVLTree<T> ret = new AVLTree<T>(); // new tree
        ret._rootOverride(this.root.copy()); // deep copy root
        return ret;                     // return clone
    }
    
    public int size() {
        return this.root.size();        // tree size
    }
    
    private void balanceLL(Node<T> node) {
        Node<T> temp = node.getRight(); // rotate right heavy
        Node<T> swap = temp.getLeft();  // subtree swap
        Node<T> prev = this.searchPrev(node.getValue()); // parent
        
        temp.pointLeft(node);           // rotate
        node.pointRight(swap);          // reattach
        
        if (prev == null)               // update parent
            return;
        if (prev.getLeft().getValue().eq(node.getValue()))
            prev.pointLeft(temp);
        else
            prev.pointRight(temp);
    }
    private void balanceRR(Node<T> node) {
        Node<T> temp = node.getLeft();  // rotate left heavy
        Node<T> swap = temp.getRight(); // subtree swap
        Node<T> prev = this.searchPrev(node.getValue());
        
        temp.pointRight(node);          // rotate
        node.pointLeft(swap);           // reattach
        
        if (prev == null)
            return;
        if (prev.getLeft().getValue().eq(node.getValue()))
            prev.pointLeft(temp);
        else
            prev.pointRight(temp);
    }
    private void balanceRL(Node<T> node) {
        Node<T> right = node.getRight(); // right subtree
        Node<T> left = right.getLeft();  // pivot
        Node<T> sl = left.getLeft();     // left subtree
        Node<T> sr = left.getRight();    // right subtree
        Node<T> prev = this.searchPrev(node.getValue());
        
        left.pointRight(right);          // rotate
        left.pointLeft(node);
        right.pointLeft(sr);
        node.pointRight(sl);
        
        if (prev == null)
            return;
        if (prev.getLeft().getValue().eq(node.getValue()))
            prev.pointLeft(left);
        else
            prev.pointRight(left);
    }
    private void balanceLR(Node<T> node) {
        Node<T> left = node.getLeft();   // left subtree
        Node<T> right = left.getRight(); // pivot
        Node<T> sl = right.getLeft();    // left subtree
        Node<T> sr = right.getRight();   // right subtree
        Node<T> prev = this.searchPrev(node.getValue());
        
        right.pointRight(node);          // rotate
        right.pointLeft(left);
        node.pointLeft(sr);
        left.pointRight(sl);
        
        if (prev == null)
            return;
        if (prev.getLeft().getValue().eq(node.getValue()))
            prev.pointLeft(right);
        else
            prev.pointRight(right);
    }
    
    private void rebalance(Node<T> node) {
        if (node.BalanceFactor() <= 1 && node.BalanceFactor() >= -1)
            return;                      // already balanced
        if (node.BalanceFactor() > 2) {
            this.rebalance(node.getLeft()); // recurse left
            return;
        }
        if (node.BalanceFactor() < -2) {
            this.rebalance(node.getRight()); // recurse right
            return;
        }
        
        if (node.BalanceFactor() > 1 && node.getLeft().BalanceFactor() >= 0) {
            this.balanceLL(node);        // ll case
            return;
        }
        if (node.BalanceFactor() < -1 && node.getLeft().BalanceFactor() <= 0) {
            this.balanceRR(node);        // rr case
            return;
        }
        if (node.BalanceFactor() > 1 && node.getLeft().BalanceFactor() < 0) {
            this.balanceLR(node);        // lr case
            return;
        }
        if (node.BalanceFactor() < -1 && node.getLeft().BalanceFactor() > 0) {
            this.balanceRL(node);        // rl case
            return;
        }
    }

    public void insert(C<T> key) {
        Node<T> temp = this.root;        // start at root
        if (root == null)                // empty tree
            root = new Node<T>(key);
        else {
            while (true)
                if (temp.getValue().gt(key)) { // go left
                    if (temp.getLeft() == null) {
                        temp.pointLeft(new Node<T>(key)); // insert
                        break;
                    } else {
                        temp = temp.getLeft();            // descend
                    }
                }
                else {                      // go right
                    if (temp.getRight() == null) {
                        temp.pointRight(new Node<T>(key)); // insert
                        break;
                    } else {
                        temp = temp.right;                // descend
                    }
                }
        }
        this.rebalance(this.root);        // restore balance
    }
    
    public void delete(C<T> key) {
        Node<T> temp = this.searchNode(key); // find node
        Node<T> prev = this.searchPrev(key); // find parent
        if (temp == null) {                 // missing
            this.rebalance(this.root);
            return;
        }
        if (temp.getRight() == null && temp.getLeft() == null) { // leaf
            if (prev.getValue().gt(temp.getValue())) {
                prev.pointLeft(null);      // remove leaf
                this.rebalance(this.root);
                return;
            }
            prev.pointRight(null);
            this.rebalance(this.root);
            return;
        }
        if (temp.getRight() == null) {      // one child left
            if (prev.getValue().gt(temp.getValue())) {
                prev.pointLeft(temp.getLeft());
                this.rebalance(this.root);
                return;
            }
            prev.pointRight(temp.getLeft());
            this.rebalance(this.root);
            return;
        }
        if (temp.left == null) {            // one child right
            if (prev.getValue().gt(temp.getValue())) {
                prev.pointLeft(temp.getRight());
                this.rebalance(this.root);
                return;
            }
            prev.pointRight(temp.getRight());
            this.rebalance(this.root);
            return;
        }
        // two children
        Node<T> min = this.getMin(temp.getRight()); // successor
        this.delete(min.getValue());                // remove successor
        min.pointLeft(temp.getLeft());              // attach children
        min.pointRight(temp.getRight());
        if (prev.getValue().gt(temp.getValue())) {
            prev.pointLeft(min);                    // replace node
            this.rebalance(this.root);
            return;
        }
        prev.pointRight(min);
        this.rebalance(this.root);
        return;
    }

    public String inorder(Node<T> root) {
        String s = "";                   // traversal string
        if (root == null)
            return s;
        s += inorder(root.getLeft());    // left
        s += root.getValue().toString() + " "; // self
        s += inorder(root.getRight());   // right
        return s;
    }
    
    public String preorder(Node<T> root) {
        String s = "";                   // traversal string
        if (root == null)
            return s;
        s += root.getValue().toString() + " "; // self
        s += this.preorder(root.left);         // left
        s += this.preorder(root.right);        // right
        return s;
    }
    
    public String postorder(Node<T> root) {
        String s = "";                   // traversal string
        if (root == null)
            return s;
        s += this.postorder(root.left);        // left
        s += this.postorder(root.right);       // right
        s += root.getValue().toString() + " "; // self
        return s;
    }
    
    private Node<T> searchNode(C<T> key) {
        Node<T> temp = this.root;        // start at root
        for (;;) {
            if (temp == null)
                return null;             // not found
            if (temp.getValue().eq(key))
                return temp;             // found
            if (temp.getValue().gt(key))
                temp = temp.getLeft();   // go left
            else
                temp = temp.getRight();  // go right
        }
    }
    
    private Node<T> searchPrev(C<T> key) {
        Node<T> temp = this.root;        // start at root
        for (;;) {
            if (temp == null)
                return null;             // no parent
            if ((temp.getLeft() != null && temp.getLeft().getValue().eq(key)) ||
                (temp.getRight() != null && temp.getRight().getValue().eq(key)))
                return temp;             // parent found
            if (temp.getValue().gt(key))
                temp = temp.getLeft();   // go left
            else
                temp = temp.getRight();  // go right
        }
    }
    
    private Node<T> getMin(Node<T> n) {
        if (n.getLeft() == null)
            return n;                    // smallest
        return getMin(n.getLeft());      // descend left
    }
    @SuppressWarnings("unused")
    private Node<T> getMax(Node<T> n) {
        if (n.getRight() == null)
            return n;                    // largest
        return getMax(n.getRight());     // descend right
    }
    
    public String toString() {
        String s = "(AVL: ";             // prefix
        s += this.inorder(this.root);    // inorder print
        return s + ")";                  // close
    }
}
