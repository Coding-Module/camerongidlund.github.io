package camtypes;

@SuppressWarnings("unchecked")
public class Tree<T> implements camObj {
    class Node<t> {
        private String id;                 // node identifier
        private t val;                     // stored value
        private LinkList<Node<t>> children; // list of child nodes
        
        public Node(String id, t value) {
            this.id = id;                  // set id
            this.val = value;              // set value
            this.children = new LinkList<Node<t>>(); // empty child list
        }
        protected void _arrayOverride(LinkList<Node<t>> arr) {
            this.children = arr;           // replace children list
        }
        public Node<t> copy() {
            // deep copy node + children
            t cVal = this.val;
            String cID = this.id + "";
            if (cVal instanceof camObj)
                cVal = (t)((camObj)cVal).copy(); // deep copy value
            
            Node<t> ret = new Node<t>(cID, cVal);
            ret._arrayOverride((LinkList<Node<t>>)this.children.copy()); // deep copy children
            return ret;
        }
        
        public int size() {
            // total nodes in subtree
            int size = 1;
            for (int i = 0; i < this.children.length(); i++)
                size += this.children.get(i).size();
            return size;
        }
        
        public int height() {
            // longest path downward
            int ret = -1;
            for (int i = 0; i < this.children.length(); i++) {
                int temp = this.children.get(i).height();
                if (temp > ret)
                    ret = temp;
            }
            return ret + 1;
        }
        
        public int childrenLen() {
            return this.children.length(); // number of children
        }
        
        public String getID() {
            return this.id;
        }
        public void setID(String id) {
            this.id = id;
        }
        
        public t getVal() {
            return this.val;
        }
        public void setVal(t value) {
            this.val = value;
        }
        
        public Node<t> getChildAt(int index) {
            return this.children.get(index);
        }
        public void addChild(String id, t value) {
            this.children.addLast(new Node<t>(id, value)); // append child
        }
        public void insertChild(int index, String id, t value) {
            this.children.insert(index, new Node<t>(id, value)); // insert child
        }
        public void deleteChild(int index) {
            this.children.remove(index); // remove child by index
        }
        public void removeChild(String id) {
            // remove child by id
            if (!this.hasChild(id))
                return;
            for (int i = 0; i < this.children.length(); i++) {
                if (this.children.get(i).getID().equals(id)) {
                    this.deleteChild(i);
                    return;
                }
            }
        }
        public boolean hasChild(String id) {
            // check if child exists
            for (int i = 0; i < this.children.length(); i++)
                if (this.children.get(i).getID().equals(id))
                    return true;
            return false;
        }
        
        public String toString() {
            // print id + value
            String s = this.id + ": ";
            if (this.val instanceof Object)
                s += this.val.toString();
            else
                s += this.val;
            return s;
        }
    }
    
    Node<T> root; // root node
    
    public Tree() {
        this.root = null; // empty tree
    }
    protected void _rootOverride(Node<T> root) {
        this.root = root; // replace root
    }
    public camObj copy() {
        // deep copy entire tree
        Tree<T> ret = new Tree<T>();
        ret._rootOverride(this.root.copy());
        return ret;
    }
    
    public String inorder(Node<T> node) {
        // generalized inorder for tree of n children
        String s = "";
        if (node == null)
            return s;
        
        if (node.childrenLen() == 0)
            s += node.getVal().toString() + " ";
        
        for (int i = 0; i < node.childrenLen(); i++) {
            if (i == node.childrenLen() / 2)
                s += node.getVal().toString() + " ";
            s += this.preorder(node.getChildAt(i));
        }
        return s;
    }
    
    public String preorder(Node<T> node) {
        // root -> children
        String s = "";
        if (node == null)
            return s;
        
        s += node.getVal().toString() + " ";
        for (int i = 0; i < node.childrenLen(); i++)
            s += this.preorder(node.getChildAt(i));
        return s;
    }
    private Node<T> preorderIndex(int index, Node<T> node) {
        // get node by preorder index
        if (index == 0)
            return node;
        
        for (int i = 0; i < node.childrenLen(); i++) {
            int n = node.getChildAt(i).size();
            if (n > index)
                return this.preorderIndex(index - 1, node.getChildAt(i));
        }
        return null;
    }
    
    public String postorder(Node<T> node) {
        // children -> root
        String s = "";
        if (node == null)
            return s;
        
        for (int i = 0; i < node.childrenLen(); i++)
            s += this.preorder(node.getChildAt(i));
        
        s += node.getVal().toString() + " ";
        return s;
    }
    
    private Node<T> searchNode(String id) {
        // search by id using preorder traversal
        for (int i = 0; i < this.root.size(); i++) {
            Node<T> temp = this.preorderIndex(i, this.root);
            if (temp.getID().equals(id))
                return temp;
        }
        return null;
    }
    private Node<T> searchNode(int[] path) {
        // search by child index path
        Node<T> temp = this.root;
        for (int i : path)
            temp = temp.getChildAt(i);
        return temp;
    }
    
    private Node<T> searchPrev(String id) {
        // find parent of node with id
        for (int i = 0; i < this.root.size(); i++) {
            Node<T> temp = this.preorderIndex(i, this.root);
            if (temp.hasChild(id))
                return temp;
        }
        return null;
    }
    private Node<T> searchPrev(int[] path) {
        // find parent by path
        Node<T> prev = null;
        Node<T> temp = this.root;
        for (int i : path) {
            prev = temp;
            temp = temp.getChildAt(i);
        }
        return prev;
    }
    
    public int size() {
        return this.root.size(); // total nodes
    }
    public int height() {
        return this.root.height(); // height of tree
    }
    public int depth() {
        return this.root.height(); // same as height
    }
    public int degree() {
        // max number of children any node has
        int ret = -1;
        for (int i = 0; i < this.root.size(); i++) {
            int temp = this.preorderIndex(i, this.root).childrenLen();
            if (temp > ret)
                ret = temp;
        }
        return ret;
    }
    
    public int nodeHeight(String id) {
        return this.searchNode(id).height();
    }
    public int nodeHeight(int[] path) {
        return this.searchNode(path).height();
    }
    
    public int nodeDepth(String id) {
        return this.root.height() - this.searchNode(id).height();
    }
    public int nodeDepth(int[] path) {
        return this.root.height() - this.searchNode(path).height();
    }
    
    public int nodeDegree(String id) {
        return this.searchNode(id).childrenLen();
    }
    public int nodeDegree(int[] path) {
        return this.searchNode(path).childrenLen();
    }
    
    public T getRoot() {
        return this.root.getVal();
    }
    public T getNode(String id) {
        return this.searchNode(id).getVal();
    }
    public T getNode(int[] path) {
        return this.searchNode(path).getVal();
    }
    
    public void add(String parent, String id, T value) {
        this.searchNode(parent).addChild(id, value);
    }
    public void add(int[] path, String id, T value) {
        this.searchNode(path).addChild(id, value);
    }
    public void insert(String parent, int index, String id, T value) {
        this.searchNode(parent).insertChild(index, id, value);
    }
    public void insert(int[] path, int index, String id, T value) {
        this.searchNode(path).insertChild(index, id, value);
    }
    
    public void delete(String id) {
        this.searchPrev(id).removeChild(id);
    }
    public void delete(int[] path) {
        Node<T> parent = this.searchPrev(path);
        parent.deleteChild(path[path.length - 1]);
    }
    public T pop(String id) {
        T ret = this.getNode(id);
        this.delete(id);
        return ret;
    }
    public T pop(int[] path) {
        T ret = this.getNode(path);
        this.delete(path);
        return ret;
    }
    public void clear() {
        this.root = null;
    }
    
    public Tree<T> subtree(String id) {
        Tree<T> ret = new Tree<T>();
        ret._rootOverride(this.searchNode(id)); // shallow subtree
        return ret;
    }
    public Tree<T> subtree(int[] path) {
        Tree<T> ret = new Tree<T>();
        ret._rootOverride(this.searchNode(path));
        return ret;
    }
    
    public Tree<T> newSubtree(String id) {
        Tree<T> ret = new Tree<T>();
        ret._rootOverride(this.searchNode(id).copy()); // deep subtree
        return ret;
    }
    public Tree<T> newSubtree(int[] path) {
        Tree<T> ret = new Tree<T>();
        ret._rootOverride(this.searchNode(path).copy());
        return ret;
    }
    
    public String toString() {
        return this.preorder(this.root); // default print
    }
}
