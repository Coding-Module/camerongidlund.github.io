package camtypes;

interface camObj {  // interface for all data structures in this package
    public camObj copy();   // required clone method
}
