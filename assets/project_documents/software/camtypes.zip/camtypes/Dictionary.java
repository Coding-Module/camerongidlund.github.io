package camtypes;

@SuppressWarnings("unchecked")
public class Dictionary<T> implements camObj {
    @SuppressWarnings("rawtypes")
    private LinkList[] table;   // array of buckets storing key value pairs
    private int size;           // number of buckets
    
    public Dictionary(int constraint) {
        this.table = new LinkList[constraint];   // allocate buckets
        for (int i = 0; i < constraint; i++) {
            this.table[i] = new LinkList<Object[]>(); // each bucket holds [key, value]
        }
        this.size = constraint;   // hash modulus
    }
    @SuppressWarnings("rawtypes")
    protected void _tableOverride(LinkList[] table) {
        this.table = table;       // replace bucket array
    }
    @SuppressWarnings("rawtypes")
    public camObj copy() {
        Dictionary<T> ret = new Dictionary<T>(this.size); // new dictionary
        LinkList[] cTable = new LinkList[this.size];      // clone buckets
        for (int i = 0; i < this.size; i++) {
            cTable[i] = (LinkList) this.table[i].copy();  // deep copy bucket
        }
        ret._tableOverride(cTable);                       // apply clone
        return ret;
    }
    
    public int size() {
        int len = 0;               // total entries
        for (int i = 0; i < this.size; i++) {
            i += this.table[i].length(); // accumulate bucket sizes
        }
        return len;
    }
    
    public int hashFunc(String s) {
        int hash = 0;              // ascii sum hash
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            hash += (int) c;
        }
        hash %= this.size;         // bucket index
        return hash;
    }
    
    public void put(String key, T value) {
        int hash = this.hashFunc(key);   // compute bucket
        Object[] bucket = {key, value};  // store pair
        this.table[hash].addLast(bucket); // append to bucket
    }
    
    public void delete(String key) {
        int hash = this.hashFunc(key);   // bucket index
        for (int i = 0; i < this.table[hash].length(); i++) {
            if (this.table[hash].get(0).equals(key)) { // match key
                this.table[hash].remove(i);            // remove entry
                return;
            }
        }
    }
    
    public T get(String key) {
        int hash = this.hashFunc(key);   // bucket index
        for (int i = 0; i < this.table[hash].length(); i++) {
            if (this.table[hash].get(0).equals(key))   // match key
                return (T) this.table[hash].get(1);    // return value
        }
        return null;                    // not found
    }
    
    public boolean containsKey(String key) {
        int hash = this.hashFunc(key);   // bucket index
        for (int i = 0; i < this.table[hash].length(); i++) {
            if (this.table[hash].get(0).equals(key))   // match key
                return true;
        }
        return false;
    }
    
    public boolean containsValue(T value) {
        // scan all buckets for matching value
        for (int i = 0; i < this.size; i++) {
            for (int j = 0; j < this.table[i].length(); i++) {
                if (this.table[i].get(1) == value)     // identity match
                    return true;
            }
        }
        return false;
    }
    
    public String toString() {
        String s = "Dictionary:\n";     // header
        for (int i = 0; i < this.size; i++) {
            s += "[";                   // bucket start
            for (int j = 0; j < this.table[i].length(); j++) {
                s += this.table[i].get(0) + ": ";      // print key
                if (this.table[i].get(1) instanceof Object)
                    s += this.table[i].get(1).toString(); // print value
                else
                    s += this.table[i].get(1);
                
                if (j != this.table[i].length() - 1)
                    s += " | ";         // separator
            }
            s += "]";                   // bucket end
            if (i != this.size - 1)
                s += "\n";
        }
        return s;
    }
}