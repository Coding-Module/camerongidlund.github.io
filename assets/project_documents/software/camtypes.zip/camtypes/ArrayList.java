package camtypes;

@SuppressWarnings("unchecked")
public class ArrayList<T> implements camObj {
    private T[] array;        // backing array
    private int size;         // current element count
    
    public ArrayList() {
        this.array = (T[]) new Object[0];   // start empty
        this.size = 0;                      // size zero
    }
    protected T[] _asList() {
        return this.array;                  // expose raw array
    }
    protected void _arrayOverride(T[] arr) {
        this.array = arr;                   // replace array
        this.size = arr.length;             // sync size
    }
    public camObj copy() {
        ArrayList<T> ret = new ArrayList<T>();     // new list
        T[] temp = (T[]) new Object[this.size];    // clone array
        for (int i = 0; i < this.size; i++) {
            if (this.array instanceof camObj[]) {  // deep copy camObj
                temp[i] = (T) ((camObj)this.array[i]).copy();
            }
            else {
                temp[i] = this.array[i];           // shallow copy
            }
        }
        ret._arrayOverride(temp);                  // apply clone
        return ret;                                // return new list
    }
    
    public int length() {
        return this.size;                          // return size
    }
    public boolean isEmpty() {
        if (this.size == 0)                        // check empty
            return true;
        return false;
    }
    
    public T get(int index) {
        if (index < 0)                              // negative index support
            index = this.size + index;
        return this.array[index];                   // return element
    }
    public boolean contains(T value) {
        for (int i = 0; i < this.size; i++) {
            if (this.array[i] == value)            // identity check
                return true;
        }
        return false;
    }
    public int indexOf(T value) {
        for (int i = 0; i < this.size; i++) {
            if (this.array[i] == value)            // find index
                return i;
        }
        return -1;                                 // not found
    }
    
    public void append(T value) {
        T[] temp = (T[]) new Object[this.size + 1]; // grow array
        for (int i = 0; i < this.size; i++) {
            temp[i] = this.array[i];               // copy old
        }
        temp[this.size]= value;                    // add new
        this.array = temp;                         // replace
        this.size++;                               // update size
    }
    public void insert(int index, T value) {
        if (index < 0)                              // negative index
            index = this.size + index;
        if (index < 0)                              // clamp low
            index = 0;
        if (index > this.size)                      // clamp high
            index = this.size;
        
        T[] temp = (T[]) new Object[this.size + 1]; // grow array
        for (int i = 0; i < index; i++) {
            temp[i] = this.array[i];               // copy before
        }
        temp[index]= value;                        // insert
        for (int i = index + 1; i <= this.size; i++) {
            temp[i] = this.array[i-1];             // shift after
        }
        this.array = temp;                         // replace
        this.size++;                               // update size
    }
    
    public void remove(int index) {
        if (index < 0)                              // negative index
            index = this.size + index;
        if (index < 0)                              // clamp low
            index = 0;
        if (index > this.size)                      // clamp high
            index = this.size - 1;
        
        T[] temp = (T[]) new Object[this.size - 1]; // shrink array
        for (int i = 0; i < index; i++) {
            temp[i] = this.array[i];               // copy before
        }
        for (int i = index + 1; i < this.size; i++) {
            temp[i-1] = this.array[i];             // shift after
        }
        this.array = temp;                         // replace
        this.size--;                               // update size
    }
    public void delete(T value) {
        int i = this.indexOf(value);               // find element
        if (i == -1)                               // skip if missing
            return;
        this.remove(i);                            // remove by index
    }
    public void clear() {
        this.array = (T[]) new Object[0];          // reset array
        this.size = 0;                             // reset size
    }
    public T pop(int index) {
        T ret = this.get(index);                   // get element
        this.remove(index);                        // remove element
        return ret;                                // return popped
    }
    
    public void set(int index, T value) {
        this.array[index] = value;                 // replace element
    }
    
    public ArrayList<T> subList(int from, int to) {
        T[] temp = (T[]) new Object[to - from];    // new slice
        for (int i = from; i < to; i++) {
            temp[i - from] = this.array[i];        // copy range
        }
        ArrayList<T> ret = new ArrayList<T>();     // new list
        ret._arrayOverride(temp);                  // apply slice
        return ret;                                // return sublist
    }
    
    public void reverse() {
        int len = this.size;                       // cache size
        for (int i = 0; i < len; i++) {
            T val = this.pop(len - 1);             // pop last
            this.insert(0, val);                   // push front
        }
    }
    public ArrayList<T> reversed() {
        ArrayList<T> ret = (ArrayList<T>) this.copy(); // clone list
        ret.reverse();                                 // reverse clone
        return ret;                                     // return reversed
    }
    
    public String toString() {
        String s = "[ ";                           // start format
        for (int i = 0; i < this.size; i++) {
            if (!(this.array instanceof Object[])) // type check
                s += this.array[i];
            else
                s += this.array[i].toString();     // stringify element
            
            if (i != this.size -1) {
                s += ", ";                         // comma between
            }
        }
        s += " ]";                                 // end format
        return s;                                   // return string
    }
}