package camtypes;

@SuppressWarnings("unchecked")
public class StaticGraph<T> implements camObj {
    private T[] vals;              // vertex values
    private int[][] adjMatrix;     // adjacency matrix storing weights
    private int verticies;         // number of vertices
    
    public StaticGraph(int size) {
        this.verticies = size;     // fixed vertex count
        this.vals = (T[]) new Object[size]; // vertex storage
        this.adjMatrix = new int[size][size]; // weight matrix
        
        // initialize all edges to 0 (no connection)
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                this.adjMatrix[i][j] = 0;
            }
        }
    }
    protected void _graphOverride(T[] values, int[][] matrix) {
        // replace internal graph
        this.vals = values;
        this.adjMatrix = matrix;
    }
    public camObj copy() {
        // deep copy graph
        StaticGraph<T> ret = new StaticGraph<T>(this.verticies);
        
        // copy vertex values
        T[] cVals = (T[]) new Object[this.verticies];
        for (int i = 0; i < this.verticies; i++) {
            if (this.vals[i] instanceof camObj)
                cVals[i] = (T)((camObj)this.vals[i]).copy(); // deep copy
            else
                cVals[i] = this.vals[i];
        }
        
        // copy adjacency matrix
        int[][] cMtx = new int[this.verticies][this.verticies];
        for (int i = 0; i < this.verticies; i++) {
            for (int j = 0; j < this.verticies; j++) {
                cMtx[i][j] = this.adjMatrix[i][j];
            }
        }
        
        ret._graphOverride(cVals, cMtx);
        return ret;
    }
    
    public int size() {
        return this.verticies;      // number of vertices
    }
    
    public T getVertex(int index) {
        return this.vals[index];    // vertex value
    }
    public void setVertex(int index, T value) {
        this.vals[index] = value;   // update vertex value
    }
    
    public void connectEdge(int from, int to, int weight) {
        // directed edge with weight
        if (from == to)
            return;                 // ignore self-loops
        this.adjMatrix[from][to] = weight;
    }
    public void connectBothEdges(int v1, int v2, int weight) {
        // undirected edge (two directed edges)
        this.connectEdge(v1, v2, weight);
        this.connectEdge(v2, v1, weight);
    }
    public void disconnectEdge(int from, int to) {
        this.adjMatrix[from][to] = 0; // remove directed edge
    }
    
    public boolean isEdgesConnected(int v1, int v2) {
        // check if either direction exists
        return this.adjMatrix[v1][v2] > 0 || this.adjMatrix[v2][v1] > 0;
    }
    public boolean isEdgesConnectedOneWay(int from, int to) {
        // check directed edge
        return this.adjMatrix[from][to] > 0;
    }
    public boolean isEdgesBothConnected(int v1, int v2) {
        // check undirected connection
        return this.adjMatrix[v1][v2] > 0 && this.adjMatrix[v2][v1] > 0;
    }
    public boolean isAlone(int vertex) {
        // check if vertex has no outgoing edges
        for (int i = 0; i < this.verticies; i++) {
            if (this.adjMatrix[vertex][i] > 0)
                return false;
        }
        return true;
    }
    
    private int[][] dijkstra(int from, int to) {
        // paths[i][0] = previous vertex
        // paths[i][1] = distance from start
        int[][] paths = new int[this.verticies][2];
        boolean[] visited = new boolean[this.verticies];
        
        // initialize path info
        for (int i = 0; i < this.verticies; i++) {
            if (i == from) {
                paths[i][0] = from;
                paths[i][1] = 0;    // start vertex distance = 0
            } else {
                paths[i][0] = -1;
                paths[i][1] = (int)Double.POSITIVE_INFINITY;
            }
            visited[i] = false;
        }
        
        int i = from;
        for (int count = 0; count < this.verticies; count++) {
            visited[i] = true;
            
            // stop early if destination reached
            if (i == to)
                return paths;
            
            // relax edges
            for (int j = 0; j < this.verticies; j++) {
                if (this.adjMatrix[i][j] > 0 && !visited[j] &&
                    (paths[i][1] + this.adjMatrix[i][j]) < paths[j][1]) {
                    
                    paths[j][0] = i;
                    paths[j][1] = paths[i][1] + this.adjMatrix[i][j];
                }
            }
            
            // select next vertex with smallest known distance
            int selected = Integer.MAX_VALUE;
            for (int j = 0; j < this.verticies; j++) {
                if (!visited[j] && paths[j][1] < selected) {
                    i = paths[j][0];
                    selected = paths[j][1];
                }
            }
        }
        return paths;
    }
    
    public int[] shortestPath(int from, int to) {
        // reconstruct path using predecessor chain
        int[][] ret = this.dijkstra(from, to);
        Stack<Integer> temp = new Stack<Integer>();
        
        int i = to;
        int count = 0;
        while (i != from) {
            temp.push(ret[i][0]);
            i = ret[i][0];
            count++;
        }
        
        int[] path = new int[count];
        for (int j = 0; j < count; j++) {
            path[j] = temp.pop();
        }
        
        return new int[0]; // placeholder return
    }
    public int shortestLength(int from, int to) {
        // return shortest path weight
        int[][] ret = this.dijkstra(from, to);
        return ret[to][1];
    }
}
