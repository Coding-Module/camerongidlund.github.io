package camtypes;

@SuppressWarnings("unchecked")
public class HashTable<K, T> implements camObj {
    @SuppressWarnings("rawtypes")
    private LinkList[] table;   // array of buckets storing [key, value] pairs
    private int size;           // number of buckets, hash modulus
    
    public HashTable(int constraint) {
        this.table = new LinkList[constraint];   // allocate bucket array
        for (int i = 0; i < constraint; i++) {
            this.table[i] = new LinkList<Object[]>(); // each bucket holds object[] pair
        }
        this.size = constraint;   // store bucket count
    }
    @SuppressWarnings("rawtypes")
    protected void _tableOverride(LinkList[] table) {
        this.table = table;       // replace internal table
    }
    @SuppressWarnings("rawtypes")
    public camObj copy() {
        HashTable<K, T> ret = new HashTable<K, T>(this.size); // new table
        LinkList[] cTable = new LinkList[this.size];          // clone buckets
        for (int i = 0; i < this.size; i++) {
            cTable[i] = (LinkList) this.table[i].copy();      // deep copy bucket
        }
        ret._tableOverride(cTable);                           // apply clone
        return ret;
    }
    
    public int size() {
        int len = 0;               // total entries across all buckets
        for (int i = 0; i < this.size; i++) {
            i += this.table[i].length(); // accumulate bucket sizes
        }
        return len;
    }
    
    public void put(C<K> key, T value) {
        int hash = key.hashFunc(this.size); // compute bucket index
        Object[] bucket = {key, value};     // store pair
        this.table[hash].addLast(bucket);   // append to bucket
    }
    
    public void delete(C<K> key) {
        int hash = key.hashFunc(this.size); // bucket index
        for (int i = 0; i < this.table[hash].length(); i++) {
            // check key at index i
            if (((C<K>)this.table[hash].get(0)).eq(key)) {
                this.table[hash].remove(i); // remove entry
                return;
            }
        }
    }
    
    public T get(C<K> key) {
        int hash = key.hashFunc(this.size); // bucket index
        for (int i = 0; i < this.table[hash].length(); i++) {
            // match key
            if (((C<K>)this.table[hash].get(0)).eq(key))
                return (T) this.table[hash].get(1); // return value
        }
        return null;                    // not found
    }
    
    public boolean containsKey(C<K> key) {
        int hash = key.hashFunc(this.size); // bucket index
        for (int i = 0; i < this.table[hash].length(); i++) {
            if (((C<K>)this.table[hash].get(0)).eq(key)) // match key
                return true;
        }
        return false;
    }
    
    public boolean containsValue(T value) {
        // scan all buckets for matching value
        for (int i = 0; i < this.size; i++) {
            for (int j = 0; j < this.table[i].length(); i++) {
                if (this.table[i].get(1) == value) // identity match
                    return true;
            }
        }
        return false;
    }
    
    public String toString() {
        String s = "Hash Table:\n";     // header
        for (int i = 0; i < this.size; i++) {
            s += "[";                   // bucket start
            for (int j = 0; j < this.table[i].length(); j++) {
                s += this.table[i].get(0).toString() + ": "; // print key
                if (this.table[i].get(1) instanceof Object)
                    s += this.table[i].get(1).toString();     // print value
                else
                    s += this.table[i].get(1);
                
                if (j != this.table[i].length() - 1)
                    s += " | ";         // separator
            }
            s += "]";                   // bucket end
            if (i != this.size - 1)
                s += "\n";
        }
        return s;
    }
}
