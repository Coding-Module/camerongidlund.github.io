/*
MONO LED ARRAY TEST CODE
Contributors: Cameron Gidlund
Acknowledgements: Dr. Scott Milkovich
Start Date: 05-06-2026
Last Update 07-31-2026
*/

const int SER = 12;    // Shift Register Serial Communication Pin
const int LATCH = 10;  // Shift Register LATCH Pin
const int CLOCK = 13; // Shift Register CLK Pin

byte matrixOff[8] = { // Pattern to turn all LEDs Off
  B00000000,
  B00000000,
  B00000000,
  B00000000,
  B00000000,
  B00000000,
  B00000000,
  B00000000
};
byte matrixOn[8] = {  // Pattern to turn all LEDs On
  B11111111,
  B11111111,
  B11111111,
  B11111111,
  B11111111,
  B11111111,
  B11111111,
  B11111111
};

void setup() {
  pinMode(SER, OUTPUT);   // Connect SER to D8
  pinMode(LATCH, OUTPUT); // Connect LATCH to D9
  pinMode(CLOCK, OUTPUT); // Connect CLK to D10

  digitalWrite(LATCH, LOW);
}

void loop() {
  // moves through rows 1 LED at a time
  led_rows();
  matrix_sys(matrixOff, 1000);

  // moves through columns 1 LED at a time
  led_cols();
  matrix_sys(matrixOn, 1000);
}

void matrix_sys(byte pattern[], long interval) {
  unsigned long startTime = millis();
  unsigned long currentTime = millis();
  while (currentTime - startTime < interval) {
    matrixWrite(pattern);
    currentTime = millis();
  }
}

void matrixWrite(byte pattern[]) {
  for (int i = 0; i < 8; i++) {
    byte row = 1 << i;      // row data stores activated row (row0: 00000001, row1: 00000010, etc.)
    byte col = pattern[i];  // column data stores pattern for given row
    
    // SHIFT REGISTER CODE
    digitalWrite(LATCH, LOW);  // Latch Low: Prevents Registers from displaying Data
    // First shift out column data (active LOW for common cathode)
    shiftOut(SER, CLOCK, MSBFIRST, ~row);
    // Then shift out row data (active HIGH for common anode)
    shiftOut(SER, CLOCK, MSBFIRST, col);
    digitalWrite(LATCH, HIGH); // Latch High: Displays Data to LEDs

    delay(1);  /* adjust as needed */
  }
}

void led_rows() {
  byte mtx[8];
  for (int r = 0; r < 8; r++) {     // LED_ON Row Position
    for (int c = 0; c < 8; c++) {   // LED_ON Col Position
      for (int i = 0; i < 8; i++) { // Matrix Index
        mtx[i] = B0;
        if (i == r)
          mtx[i] = 1 << c;
      }
      matrixWrite(mtx);  // writes pattern to LEDs
      delay(25);  /* LED Speed: adjust as needed */
    }
  }
}
void led_cols() {
  byte mtx[8];
  for (int c = 0; c < 8; c++) {     // LED_ON Col Position
    for (int r = 0; r < 8; r++) {   // LED_ON Row Position
      for (int i = 0; i < 8; i++) { // Matrix Index
        mtx[i] = B0;
        if (i == r)
          mtx[i] = 1 << c;
      }
      matrixWrite(mtx);  // writes pattern to LEDs
      delay(10);  /* LED Speed: adjust as needed */
    }
  }
}